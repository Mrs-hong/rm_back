========================================
  GetTableRow 定时数据库查询服务
========================================

1. 简介
   本程序每 5 秒连接本地 MySQL（端口 3306），查询 test_db.test_table 表行数并输出日志。

2. 快速开始
   a) 初始化数据库：
      mysql -u root -p < sql/init.sql

   b) 运行程序：
      ./bin/get_table_row

   c) 停止程序：
      按 Ctrl+C 或发送 SIGTERM 信号。

3. 重新编译
   bash scripts/build.sh

4. 重新打包
   bash scripts/package.sh

========================================
