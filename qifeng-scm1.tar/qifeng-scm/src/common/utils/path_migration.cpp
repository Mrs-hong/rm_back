/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "common/utils/path_migration.h"

#include "common/scmd_def.h"
#include "common/utils/file.h"
#include "common/utils/path.h"
#include "qifeng_framework/common/logger.h"

#include <filesystem>
#include <string>
#include <system_error>
#include <vector>

#include <yaml-cpp/yaml.h>

namespace fs = std::filesystem;

namespace qifeng::scm::utils {

    namespace {
        /// scmd 管理的 systemd 单元文件目录
        constexpr const char *SystemdUnitDir = "/etc/systemd/system";
        // scmd 服务单元文件前缀复用 common 层 ScmdServiceFilePrefix（scmd_def.h），
        // 与 FileManager::ServiceFilePrefix 保持单一来源，避免常量重复
        /// nginx 配置目录列表
        constexpr const char *NginxConfDir = "/etc/nginx/conf.d";
        constexpr const char *NginxSnippetsDir = "/etc/nginx/snippets";
        /// scmd 管理的 nginx 配置文件前缀
        constexpr const char *ScmNginxPrefix = "scm_";
        /// root_dir 下需要迁移的子目录列表（函数内 static 保证初始化顺序安全）
        const std::vector<std::string> &RootDirSubDirs() {
            static const std::vector<std::string> SubDirs = {"services", "data", "backup", "log", "tmp"};
            return SubDirs;
        }

        /// 判断 target 是否以 prefix 为路径前缀（精确匹配或 prefix/... 形式）
        bool HasPathPrefix(const std::string &target, const std::string &prefix) {
            if (target == prefix) {
                return true;
            }
            if (target.size() > prefix.size() && target.compare(0, prefix.size(), prefix) == 0 &&
                target[prefix.size()] == '/') {
                return true;
            }
            return false;
        }

        /// 将 target 中的 oldPrefix 前缀替换为 newPrefix
        std::string ReplacePathPrefix(const std::string &target, const std::string &oldPrefix,
                                      const std::string &newPrefix) {
            return newPrefix + target.substr(oldPrefix.size());
        }

        /// 拷贝 src 到 dst 后清理 src（合并迁移的公共步骤）
        /// keepSrcDir=true 时仅清空 src 内容（保留空目录，用于目标已存在的合并语义）；
        /// keepSrcDir=false 时删除 src 整个目录（用于跨文件系统 EXDEV 兜底）
        ResultMsg CopyAndCleanSource(const std::string &src, const std::string &dst, bool keepSrcDir) {
            auto copyRet = CopyDirectory(src, dst);
            if (!copyRet.IsDefalutSuccess()) {
                return MakeError("Cross-filesystem copy failed: " + copyRet.msg);
            }
            auto cleanRet = keepSrcDir ? ClearDirectoryContents(src) : ForceDeleteDirectory(src);
            if (!cleanRet.IsDefalutSuccess()) {
                SLOG_WARN << "MigrateDirSafe: clean source dir failed after copy: " << cleanRet.msg;
            }
            return MakeSuccess();
        }

        /// 跨文件系统安全的目录迁移：先尝试 rename，目标已存在或 EXDEV 时回退到 copy+清理
        ResultMsg MigrateDirSafe(const std::string &src, const std::string &dst) {
            std::error_code ec;
            if (!fs::exists(src, ec)) {
                return MakeSuccess();  // 源不存在视为无需迁移
            }

            // 确保目标父目录存在
            fs::path dstParent = fs::path(dst).parent_path();
            if (!dstParent.empty() && !fs::exists(dstParent, ec)) {
                fs::create_directories(dstParent, ec);
                if (ec) {
                    return MakeError("Failed to create parent dir of " + dst + ": " + ec.message());
                }
            }

            // 目标已存在：合并语义，copy 后仅清空源目录（保留空目录）
            if (fs::exists(dst, ec)) {
                return CopyAndCleanSource(src, dst, /*keepSrcDir=*/true);
            }

            // 目标不存在：优先 rename（同文件系统原子高效），失败再 copy+delete
            fs::rename(src, dst, ec);
            if (!ec) {
                return MakeSuccess();
            }
            if (ec.value() == EXDEV) {
                // 跨文件系统：copy 后删除源目录
                return CopyAndCleanSource(src, dst, /*keepSrcDir=*/false);
            }
            return MakeError("Failed to migrate dir " + src + " -> " + dst + ": " + ec.message());
        }

        /// 扫描指定目录下匹配 namePrefix 的软链接，将 target 中 oldPath 前缀替换为 newPath
        // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
        ResultMsg RepointSymlinksInDir(const std::string &scanDir, const std::string &namePrefix,
                                       const std::string &oldPath, const std::string &newPath) {
            std::error_code ec;
            if (!fs::exists(scanDir, ec)) {
                return MakeSuccess();  // 目录不存在视为无需处理
            }

            for (const auto &entry : fs::directory_iterator(scanDir, ec)) {
                if (ec) {
                    break;
                }
                std::error_code linkEc;
                if (!fs::is_symlink(entry.path(), linkEc)) {
                    continue;
                }

                std::string filename = entry.path().filename().string();
                if (filename.rfind(namePrefix, 0) != 0) {
                    continue;  // 不属于 scm 管理的文件
                }

                auto target = fs::read_symlink(entry.path(), linkEc);
                if (linkEc) {
                    SLOG_WARN << "RepointSymlinksInDir: read_symlink failed: " << entry.path().string()
                              << ": " << linkEc.message();
                    continue;
                }

                std::string targetStr = target.string();
                if (!HasPathPrefix(targetStr, oldPath)) {
                    continue;  // target 不指向旧路径，无需重定向
                }

                std::string newTarget = ReplacePathPrefix(targetStr, oldPath, newPath);
                std::string linkPath = entry.path().string();

                std::error_code rmEc;
                fs::remove(linkPath, rmEc);
                if (rmEc) {
                    SLOG_WARN << "RepointSymlinksInDir: remove old symlink failed: " << linkPath
                              << ": " << rmEc.message();
                    continue;
                }

                std::error_code createEc;
                fs::create_symlink(newTarget, linkPath, createEc);
                if (createEc) {
                    SLOG_WARN << "RepointSymlinksInDir: create new symlink failed: " << linkPath
                              << " -> " << newTarget << ": " << createEc.message();
                } else {
                    SLOG_INFO << "RepointSymlinksInDir: " << linkPath << " -> " << newTarget;
                }
            }
            return MakeSuccess();
        }
    }  // namespace

    ResultMsg ParseOldPathsFromBackup(const std::string &backupConfigPath, OldPathInfo &outInfo) {
        std::error_code ec;
        if (!fs::exists(backupConfigPath, ec)) {
            return MakeError("Backup config file not found: " + backupConfigPath);
        }

        try {
            YAML::Node config = YAML::LoadFile(backupConfigPath);
            if (!config["scmd"]) {
                return MakeError("Invalid backup config: missing 'scmd' root node");
            }
            YAML::Node scmd = config["scmd"];
            if (scmd["root_dir"]) {
                outInfo.rootDir = scmd["root_dir"].as<std::string>();
            }
            if (scmd["model_dir"]) {
                outInfo.modelDir = scmd["model_dir"].as<std::string>();
            }
            return MakeSuccess();
        } catch (const YAML::Exception &e) {
            return MakeError(std::string("YAML parse error in backup config: ") + e.what());
        } catch (const std::exception &e) {
            return MakeError(std::string("Failed to parse backup config: ") + e.what());
        }
    }

    ResultMsg MigrateRootDirContents(const std::string &oldRootDir, const std::string &newRootDir) {
        if (oldRootDir.empty() || newRootDir.empty()) {
            return MakeError("Root dir path is empty");
        }
        if (NormalizePath(oldRootDir) == NormalizePath(newRootDir)) {
            return MakeSuccess();
        }

        std::error_code ec;
        if (!fs::exists(oldRootDir, ec)) {
            SLOG_INFO << "MigrateRootDirContents: old root_dir not exist, skip: " << oldRootDir;
            return MakeSuccess();
        }

        // 确保新 root_dir 存在
        auto mkdirRet = CreateDirectory(newRootDir);
        if (!mkdirRet.IsDefalutSuccess()) {
            return MakeError("Failed to create new root_dir: " + mkdirRet.msg);
        }

        int failCount = 0;
        for (const auto &subDir : RootDirSubDirs()) {
            std::string oldSub = JoinPath(oldRootDir, subDir);
            std::string newSub = JoinPath(newRootDir, subDir);
            if (!fs::exists(oldSub, ec)) {
                continue;  // 旧子目录不存在，跳过
            }
            auto ret = MigrateDirSafe(oldSub, newSub);
            if (!ret.IsDefalutSuccess()) {
                SLOG_WARN << "MigrateRootDirContents: migrate " << subDir << " failed: " << ret.msg;
                ++failCount;
            } else {
                SLOG_INFO << "MigrateRootDirContents: " << subDir << " migrated " << oldSub << " -> " << newSub;
            }
        }

        if (failCount == static_cast<int>(RootDirSubDirs().size()) && failCount > 0) {
            return MakeError("All subdirectory migrations failed for root_dir");
        }
        return MakeSuccess();
    }

    ResultMsg MigrateModelDir(const std::string &oldModelDir, const std::string &newModelDir) {
        if (oldModelDir.empty() || newModelDir.empty()) {
            return MakeError("Model dir path is empty");
        }
        if (NormalizePath(oldModelDir) == NormalizePath(newModelDir)) {
            return MakeSuccess();
        }

        std::error_code ec;
        if (!fs::exists(oldModelDir, ec)) {
            SLOG_INFO << "MigrateModelDir: old model_dir not exist, skip: " << oldModelDir;
            return MakeSuccess();
        }

        auto ret = MigrateDirSafe(oldModelDir, newModelDir);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to migrate model_dir " + oldModelDir + " -> " + newModelDir + ": " + ret.msg);
        }
        SLOG_INFO << "MigrateModelDir: " << oldModelDir << " -> " << newModelDir;
        return MakeSuccess();
    }

    ResultMsg RepointSystemdSymlinks(const std::string &oldInitDir, const std::string &newInitDir) {
        if (oldInitDir.empty() || newInitDir.empty() ||
            NormalizePath(oldInitDir) == NormalizePath(newInitDir)) {
            return MakeSuccess();
        }
        return RepointSymlinksInDir(SystemdUnitDir, ScmdServiceFilePrefix, oldInitDir, newInitDir);
    }

    ResultMsg RepointNginxSymlinks(const std::string &oldServiceDir, const std::string &newServiceDir) {
        if (oldServiceDir.empty() || newServiceDir.empty() ||
            NormalizePath(oldServiceDir) == NormalizePath(newServiceDir)) {
            return MakeSuccess();
        }

        // nginx conf.d 与 snippets 两个目录均需扫描
        auto ret1 = RepointSymlinksInDir(NginxConfDir, ScmNginxPrefix, oldServiceDir, newServiceDir);
        auto ret2 = RepointSymlinksInDir(NginxSnippetsDir, ScmNginxPrefix, oldServiceDir, newServiceDir);
        if (!ret1.IsDefalutSuccess()) {
            return ret1;
        }
        return ret2;
    }

}  // namespace qifeng::scm::utils
