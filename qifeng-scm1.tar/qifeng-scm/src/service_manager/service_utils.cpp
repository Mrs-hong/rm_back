/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

// service_utils.cpp: ServiceManager 共享底层工具方法的实现
// 从 service_manager.cpp 拆分而来（Task 10）。
//
// 文件内仅为 service_utils 命名空间下的自由函数（ToSystemdUnitName / IsTarPackage）：
// 纯工具函数，不依赖 ServiceManager 实例状态，声明位于 service_utils.h。

#include "service_manager/service_utils.h"

#include "common/utils/string.h"
#include "service_manager/file_manager.h"

namespace qifeng::scm {

    namespace service_utils {

        std::string ToSystemdUnitName(const std::string &serviceName) {
            return std::string(FileManager::GetServiceFilePrefix()) + serviceName;
        }

        bool IsTarPackage(const std::string &path) {
            // 使用后缀匹配修复旧代码 find_last_of 的 BUG
            return utils::HasSuffix(path, ".tar.gz") || utils::HasSuffix(path, ".tgz");
        }

    }  // namespace service_utils

}  // namespace qifeng::scm
