/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "service_manager/model_manager.h"

#include "common/config.h"
#include "common/utils/file.h"
#include "common/utils/path.h"
#include "qifeng_framework/common/logger.h"
#include "service_manager/file_manager.h"
#include "service_manager/service_context.h"
#include "service_manager/service_manager.h"
#include "service_manager/service_utils.h"

#include <chrono>
#include <cstdint>
#include <filesystem>
#include <system_error>
#include <thread>
#include <utility>

namespace fs = std::filesystem;

namespace qifeng::scm {

    namespace {
        // 文件级备份记录：记录被覆盖文件的原始路径与备份路径
        struct FileBackupRecord {
            std::string originalPath;  // 被覆盖前的目标文件路径
            std::string backupPath;    // 备份路径（originalPath + ".back"）
        };

        /**
         * @brief 递归收集源目录下所有常规文件
         * @param srcDir 当前递归到的源目录
         * @param relBase 相对 srcDir 根的累计相对路径前缀
         * @param outFiles 输出 (srcFile 绝对路径, 相对路径) 列表，相对路径用于在 modelDir 下镜像源结构
         */
        void CollectSourceFiles(const fs::path &srcDir, const fs::path &relBase,
                                std::vector<std::pair<std::string, std::string>> &outFiles) {
            std::error_code ec;
            for (auto it = fs::directory_iterator(srcDir, ec); it != fs::directory_iterator(); it.increment(ec)) {
                if (ec) {
                    ec.clear();
                    continue;
                }
                const auto &entry = *it;
                fs::path rel = relBase / entry.path().filename();
                if (entry.is_directory()) {
                    CollectSourceFiles(entry.path(), rel, outFiles);
                } else if (entry.is_regular_file()) {
                    outFiles.emplace_back(entry.path().string(), rel.string());
                }
            }
        }

        /**
         * @brief 回滚已处理的文件：恢复 .back 备份、删除本次新增文件
         * @details 逆序处理，保证与写入顺序相反；各文件操作相互独立，忽略单文件回滚错误以保证流程继续。
         * @param replacedFiles 已存在并被备份的文件记录
         * @param newFiles 本次新增（无备份）的目标文件路径
         */
        void RollbackProcessedFiles(const std::vector<FileBackupRecord> &replacedFiles,
                                    const std::vector<std::string> &newFiles) {
            // 逆序恢复被覆盖的文件：删除新复制的文件，再将 .back 恢复为原名
            for (auto it = replacedFiles.rbegin(); it != replacedFiles.rend(); ++it) {
                std::error_code ec;
                fs::remove(it->originalPath, ec);  // 删除新文件（不存在则忽略）
                if (fs::exists(it->backupPath, ec)) {
                    fs::rename(it->backupPath, it->originalPath, ec);  // 恢复备份
                }
            }
            // 逆序删除本次新增的文件（无 .back，直接删除）
            for (auto it = newFiles.rbegin(); it != newFiles.rend(); ++it) {
                std::error_code ec;
                fs::remove(*it, ec);
            }
        }

        /**
         * @brief 处理单个文件：备份已有文件、复制新文件
         * @details 确保目标父目录存在；若目标已存在则重命名为 <dstFile>.back 并记入 replacedFiles，
         *          否则记入 newFiles；随后 fs::copy_file 覆盖。失败时返回错误（不回滚，由调用方回滚）。
         * @param srcFile 源文件绝对路径
         * @param dstFile 目标文件绝对路径
         * @param replacedFiles 累积的被覆盖文件备份记录
         * @param newFiles 累积的本次新增文件目标路径
         * @return ResultMsg 单文件处理结果
         */
        ResultMsg MergeOneFile(const std::string &srcFile, const std::string &dstFile,
                               std::vector<FileBackupRecord> &replacedFiles,
                               std::vector<std::string> &newFiles) {
            std::error_code ec;

            // 确保目标父目录存在（镜像源目录结构）
            fs::path dstParent = fs::path(dstFile).parent_path();
            if (!dstParent.empty()) {
                fs::create_directories(dstParent, ec);
                if (ec) {
                    return MakeError("Failed to create destination directory " + dstParent.string() +
                                     ": " + ec.message());
                }
            }

            // 目标已存在：备份为 <dstFile>.back（残留 .back 先清理）
            if (fs::exists(dstFile, ec)) {
                std::string backupPath = dstFile + ".back";
                if (fs::exists(backupPath, ec)) {
                    fs::remove(backupPath, ec);  // 清理上次残留备份
                }
                fs::rename(dstFile, backupPath, ec);
                if (ec) {
                    return MakeError("Failed to backup existing file " + dstFile + ": " + ec.message());
                }
                replacedFiles.push_back({dstFile, backupPath});
            } else {
                newFiles.push_back(dstFile);
            }

            // 复制源文件到目标（统一使用 overwrite_existing，rename 已腾出位置时同样安全）
            fs::copy_file(srcFile, dstFile, fs::copy_options::overwrite_existing, ec);
            if (ec) {
                return MakeError("Failed to copy file " + srcFile + " -> " + dstFile + ": " + ec.message());
            }
            return MakeSuccess();
        }

        /**
         * @brief 文件级合并：将 srcDir 内容逐文件合并到 modelDir
         * @details 递归遍历 srcDir，对每个常规文件：确保目标父目录存在；若目标已存在则重命名为
         *          <dstFile>.back 并记入 replacedFiles，否则记入 newFiles；随后 fs::copy_file 覆盖。
         *          任一文件失败时内部已回滚（恢复 .back、删除新增），调用方仅需恢复服务状态。
         * @param srcDir 准备好的源目录（其内容合并到 modelDir）
         * @param modelDir 模型目录（合并目标）
         * @param replacedFiles 输出：被覆盖文件的备份记录
         * @param newFiles 输出：本次新增文件的目标路径
         * @return ResultMsg 全部复制成功返回成功，否则返回失败原因（内部已回滚）
         */
        ResultMsg MergeModelFiles(const std::string &srcDir, const std::string &modelDir,
                                  std::vector<FileBackupRecord> &replacedFiles,
                                  std::vector<std::string> &newFiles) {
            std::vector<std::pair<std::string, std::string>> srcFiles;
            CollectSourceFiles(srcDir, "", srcFiles);
            if (srcFiles.empty()) {
                return MakeError("Model source directory is empty: " + srcDir);
            }

            for (const auto &kv : srcFiles) {
                std::string dstFile = utils::JoinPath(modelDir, kv.second);
                auto ret = MergeOneFile(kv.first, dstFile, replacedFiles, newFiles);
                if (!ret.IsDefalutSuccess()) {
                    // 单文件失败：回滚已处理文件后返回错误
                    RollbackProcessedFiles(replacedFiles, newFiles);
                    return ret;
                }
            }
            return MakeSuccess();
        }
    }  // namespace

    ModelManager::ModelManager(const ServiceContext &ctx) : mCtx(ctx) {
    }

    ModelManager::~ModelManager() = default;

    // --- 模型管理 ---

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg ModelManager::AddModel(const std::string &srcPath) {
        // 1. 前置校验
        if (srcPath.empty()) {
            return MakeError("Model source path is empty");
        }
        const auto &configInfo = mCtx.configLoader->GetConfigInfo();
        if (configInfo.modelDir.empty()) {
            return MakeError("model_dir is not configured in scmd.yaml");
        }
        if (!fs::exists(srcPath)) {
            return MakeError("Model source path does not exist: " + srcPath);
        }

        // 确保模型目录存在（惰性创建，与 nginx 目录处理风格一致）
        auto mkdirRet = utils::CreateDirectory(configInfo.modelDir);
        if (!mkdirRet.IsDefalutSuccess()) {
            return MakeError("Failed to create model_dir: " + mkdirRet.msg);
        }

        // 2. 解析模型名并准备源目录
        //    - tar/tar.gz：解压到临时目录，取解压后唯一顶层目录名为模型名
        //    - 目录：basename 为模型名
        std::string modelName;
        std::string preparedSrcDir;  // 最终用于移动到 modelDir 的源目录
        std::string tempDir;         // tar 解压临时目录（非空时需要清理）
        if (service_utils::IsTarPackage(srcPath)) {
            tempDir = utils::GenerateTempDir(mCtx.fileManager->GetCurDirConfig().tempDir);
            auto extractRet = mCtx.serviceManager->ExtractSoftwareTar(srcPath, tempDir);
            if (!extractRet.IsDefalutSuccess()) {
                mCtx.serviceManager->CleanupTempDirectory(tempDir);
                return MakeError("Failed to extract model tar: " + extractRet.msg);
            }
            // 取解压目录下唯一的顶层条目名（要求是目录）
            modelName = utils::GetSingleTopLevelEntryName(tempDir);
            if (modelName.empty()) {
                mCtx.serviceManager->CleanupTempDirectory(tempDir);
                return MakeError("Model tar must contain exactly one top-level directory");
            }
            preparedSrcDir = utils::JoinPath(tempDir, modelName);
        } else if (fs::is_directory(srcPath)) {
            modelName = fs::path(srcPath).filename().string();
            preparedSrcDir = srcPath;
        } else {
            return MakeError("Invalid model path (not tar.gz or directory): " + srcPath);
        }

        auto nameRet = ValidateModelName(modelName);
        if (!nameRet.IsDefalutSuccess()) {
            mCtx.serviceManager->CleanupTempDirectory(tempDir);
            return nameRet;
        }

        std::string modelDir = configInfo.modelDir;

        // 3. 停止依赖模型的服务，记录停止前状态
        auto dependentServices = GetModelDependentServices();
        std::map<std::string, bool> preStates;
        auto stopRet = StopServicesWithStateRecord(dependentServices, preStates);
        if (!stopRet.IsDefalutSuccess()) {
            // 停止失败直接返回，不修改模型文件
            mCtx.serviceManager->CleanupTempDirectory(tempDir);
            return MakeError("Failed to stop model-dependent services: " + stopRet.msg);
        }

        // 4. 文件级合并：逐文件备份已存在文件并复制新文件到 modelDir
        //    replacedFiles 记录被覆盖文件（含 .back 备份路径），newFiles 记录本次新增文件
        std::vector<FileBackupRecord> replacedFiles;
        std::vector<std::string> newFiles;
        auto mergeRet = MergeModelFiles(preparedSrcDir, modelDir, replacedFiles, newFiles);
        // 合并完成后源临时目录不再需要，统一清理
        mCtx.serviceManager->CleanupTempDirectory(tempDir);
        if (!mergeRet.IsDefalutSuccess()) {
            // MergeModelFiles 内部已回滚已处理文件（恢复 .back、删除新增）
            RestoreServicesByState(preStates);
            return MakeError("Failed to copy model files: " + mergeRet.msg);
        }

        // 5. 启动依赖服务并按各自 keep_alive_time_sec 验证持续运行
        auto verifyRet = StartServicesAndWaitRunning(dependentServices);
        if (!verifyRet.IsDefalutSuccess()) {
            SLOG_ERROR << "Model verification failed: " << verifyRet.msg << ", rolling back model files";
            // 精确回滚：删除新文件、恢复 .back 备份，未触及的既有文件不受影响
            RollbackProcessedFiles(replacedFiles, newFiles);
            RestoreServicesByState(preStates);
            return MakeError("Model verification failed, rolled back: " + verifyRet.msg);
        }

        // 6. 验证通过，恢复服务起初状态（原本运行的保持运行，原本停止的停止）
        RestoreServicesByState(preStates);

        // 7. 清理 .back 备份（add_model 成功后不再保留 .back，单个删除失败仅告警）
        for (const auto &rec : replacedFiles) {
            std::error_code ec;
            fs::remove(rec.backupPath, ec);
            if (ec) {
                SLOG_WARN << "Failed to clean backup file " << rec.backupPath << ": " << ec.message();
            }
        }

        SLOG_INFO << "Model added successfully: " << modelName;
        return MakeSuccess();
    }

    std::vector<std::string> ModelManager::GetModelDependentServices(const std::string &excludeService) {
        std::vector<std::string> result;
        auto allServices = mCtx.configLoader->GetAllServices();
        for (const auto &svc : allServices) {
            if (svc.needModel && svc.serviceName != excludeService) {
                result.push_back(svc.serviceName);
            }
        }
        return result;
    }

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg ModelManager::AddModelWithBackupRetained(const std::string &srcPath, const std::string &excludeService,
                                                       std::string &modelName,
                                                       std::vector<std::string> &backupFiles) {
        // 与 AddModel 文件级流程一致，但：1) 排除 excludeService  2) 成功后不清理 .back，由调用方清理/回退
        backupFiles.clear();
        if (srcPath.empty()) {
            return MakeError("Model source path is empty");
        }
        const auto &configInfo = mCtx.configLoader->GetConfigInfo();
        if (configInfo.modelDir.empty()) {
            return MakeError("model_dir is not configured in scmd.yaml");
        }
        if (!fs::exists(srcPath)) {
            return MakeError("Model source path does not exist: " + srcPath);
        }

        auto mkdirRet = utils::CreateDirectory(configInfo.modelDir);
        if (!mkdirRet.IsDefalutSuccess()) {
            return MakeError("Failed to create model_dir: " + mkdirRet.msg);
        }

        // 解析模型名并准备源目录（modelName 仅作标签，文件级合并不创建以 modelName 命名的子目录）
        std::string preparedSrcDir;
        std::string tempDir;
        if (service_utils::IsTarPackage(srcPath)) {
            tempDir = utils::GenerateTempDir(mCtx.fileManager->GetCurDirConfig().tempDir);
            auto extractRet = mCtx.serviceManager->ExtractSoftwareTar(srcPath, tempDir);
            if (!extractRet.IsDefalutSuccess()) {
                mCtx.serviceManager->CleanupTempDirectory(tempDir);
                return MakeError("Failed to extract model tar: " + extractRet.msg);
            }
            modelName = utils::GetSingleTopLevelEntryName(tempDir);
            if (modelName.empty()) {
                mCtx.serviceManager->CleanupTempDirectory(tempDir);
                return MakeError("Model tar must contain exactly one top-level directory");
            }
            preparedSrcDir = utils::JoinPath(tempDir, modelName);
        } else if (fs::is_directory(srcPath)) {
            modelName = fs::path(srcPath).filename().string();
            preparedSrcDir = srcPath;
        } else {
            return MakeError("Invalid model path (not tar.gz or directory): " + srcPath);
        }

        auto nameRet = ValidateModelName(modelName);
        if (!nameRet.IsDefalutSuccess()) {
            mCtx.serviceManager->CleanupTempDirectory(tempDir);
            return nameRet;
        }

        std::string modelDir = configInfo.modelDir;

        // 停止依赖模型的服务（排除当前升级服务）
        auto dependentServices = GetModelDependentServices(excludeService);
        std::map<std::string, bool> preStates;
        auto stopRet = StopServicesWithStateRecord(dependentServices, preStates);
        if (!stopRet.IsDefalutSuccess()) {
            mCtx.serviceManager->CleanupTempDirectory(tempDir);
            return MakeError("Failed to stop model-dependent services: " + stopRet.msg);
        }

        // 文件级合并：逐文件备份已存在文件并复制新文件到 modelDir
        std::vector<FileBackupRecord> replacedFiles;
        std::vector<std::string> newFiles;
        auto mergeRet = MergeModelFiles(preparedSrcDir, modelDir, replacedFiles, newFiles);
        mCtx.serviceManager->CleanupTempDirectory(tempDir);
        if (!mergeRet.IsDefalutSuccess()) {
            // MergeModelFiles 内部已回滚已处理文件（恢复 .back、删除新增）
            RestoreServicesByState(preStates);
            return MakeError("Failed to copy model files: " + mergeRet.msg);
        }

        // 启动依赖服务并验证
        auto verifyRet = StartServicesAndWaitRunning(dependentServices);
        if (!verifyRet.IsDefalutSuccess()) {
            SLOG_ERROR << "Model verification failed: " << verifyRet.msg << ", rolling back model files";
            RollbackProcessedFiles(replacedFiles, newFiles);
            RestoreServicesByState(preStates);
            return MakeError("Model verification failed, rolled back: " + verifyRet.msg);
        }

        // 验证通过，恢复服务起初状态（注意：不清理 .back 备份，由调用方负责）
        RestoreServicesByState(preStates);

        // 输出本次产生的 .back 备份路径列表，供调用方调用 CleanModelBackupFiles/RollbackModelFiles
        for (const auto &rec : replacedFiles) {
            backupFiles.push_back(rec.backupPath);
        }

        SLOG_INFO << "Model added (backup retained): " << modelName
                  << ", backup files: " << backupFiles.size();
        return MakeSuccess();
    }

    ResultMsg ModelManager::CleanModelBackupFiles(const std::vector<std::string> &backupFiles) {
        // 逐个删除 .back 备份文件（单个失败仅告警，不中断整体清理）
        for (const auto &path : backupFiles) {
            std::error_code ec;
            if (!fs::exists(path, ec)) {
                continue;  // 备份不存在视为已清理
            }
            fs::remove(path, ec);
            if (ec) {
                SLOG_WARN << "Failed to clean backup file " << path << ": " << ec.message();
            }
        }
        SLOG_INFO << "Model backup files cleaned, count: " << backupFiles.size();
        return MakeSuccess();
    }

    ResultMsg ModelManager::RollbackModelFiles(const std::vector<std::string> &backupFiles) {
        // 逆序回退被覆盖的文件：删除覆盖后产生的新文件，将 .back 恢复为原名（去掉 ".back" 后缀）
        // 注意：仅回退 backupFiles 中记录的被覆盖文件；本次新增的文件（无 .back）不在此处理范围
        for (auto it = backupFiles.rbegin(); it != backupFiles.rend(); ++it) {
            const std::string &backupPath = *it;
            // 校验 .back 后缀并推导原始路径
            if (backupPath.size() < 5 || backupPath.compare(backupPath.size() - 5, 5, ".back") != 0) {
                SLOG_WARN << "Skip invalid backup path (not ending with .back): " << backupPath;
                continue;
            }
            std::string originalPath = backupPath.substr(0, backupPath.size() - 5);
            std::error_code ec;
            fs::remove(originalPath, ec);  // 删除覆盖后产生的新文件（不存在则忽略）
            if (fs::exists(backupPath, ec)) {
                fs::rename(backupPath, originalPath, ec);  // 恢复 .back 为原名
                if (ec) {
                    SLOG_ERROR << "Failed to restore backup " << backupPath << " -> " << originalPath
                               << ": " << ec.message();
                }
            }
        }
        SLOG_INFO << "Model files rolled back, count: " << backupFiles.size();
        return MakeSuccess();
    }

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg ModelManager::ClearModel(const std::string &modelName) {
        // 1. 前置校验
        auto nameRet = ValidateModelName(modelName);
        if (!nameRet.IsDefalutSuccess()) {
            return nameRet;
        }
        const auto &configInfo = mCtx.configLoader->GetConfigInfo();
        if (configInfo.modelDir.empty()) {
            return MakeError("model_dir is not configured in scmd.yaml");
        }

        std::string modelDir = configInfo.modelDir;
        std::string modelPath = utils::JoinPath(modelDir, modelName);
        std::string backupPath = utils::JoinPath(modelDir, modelName + ".back");

        if (!fs::exists(modelPath)) {
            return MakeError("Model does not exist: " + modelPath);
        }

        // 2. 停止依赖模型的服务
        auto dependentServices = GetModelDependentServices();
        std::map<std::string, bool> preStates;
        auto stopRet = StopServicesWithStateRecord(dependentServices, preStates);
        if (!stopRet.IsDefalutSuccess()) {
            return MakeError("Failed to stop model-dependent services: " + stopRet.msg);
        }

        // 3. 重命名模型为 <name>.back（若已存在先删除）
        if (fs::exists(backupPath)) {
            utils::ForceDeleteDirectory(backupPath);
        }
        std::error_code ec;
        fs::rename(modelPath, backupPath, ec);
        if (ec) {
            RestoreServicesByState(preStates);
            return MakeError("Failed to rename model to .back: " + ec.message());
        }

        // 4. 启动依赖服务并按各自 keep_alive_time_sec 验证持续运行
        auto verifyRet = StartServicesAndWaitRunning(dependentServices);
        if (!verifyRet.IsDefalutSuccess()) {
            SLOG_ERROR << "Model clear verification failed: " << verifyRet.msg << ", rolling back";
            // 回退：恢复模型名
            std::error_code renameEc;
            fs::rename(backupPath, modelPath, renameEc);
            RestoreServicesByState(preStates);
            return MakeError("Model clear verification failed, rolled back: " + verifyRet.msg);
        }

        // 5. 验证通过，恢复服务起初状态
        RestoreServicesByState(preStates);

        // 6. 清理 .back 备份（clear_model 成功后不再保留 .back，与 add_model 行为对称）
        if (fs::exists(backupPath)) {
            utils::ForceDeleteDirectory(backupPath);
        }

        SLOG_INFO << "Model cleared successfully: " << modelName;
        return MakeSuccess();
    }

    // --- 模型管理辅助 ---

    std::vector<std::string> ModelManager::GetModelDependentServices() {
        std::vector<std::string> result;
        auto allServices = mCtx.configLoader->GetAllServices();
        for (const auto &svc : allServices) {
            if (svc.needModel) {
                result.push_back(svc.serviceName);
            }
        }
        return result;
    }

    ResultMsg ModelManager::StopServicesWithStateRecord(const std::vector<std::string> &serviceNames,
                                                        std::map<std::string, bool> &preStates) {
        preStates.clear();
        for (const auto &name : serviceNames) {
            // 记录停止前是否在运行
            bool wasRunning = mCtx.serviceManager->IsServiceActive(name);
            preStates[name] = wasRunning;
            if (wasRunning) {
                auto stopRet = mCtx.serviceManager->StopService(name);
                if (!stopRet.IsDefalutSuccess()) {
                    // 停止失败：已停止的服务保持原状态记录，直接返回错误
                    return MakeError("Failed to stop service " + name + ": " + stopRet.msg);
                }
            }
        }
        return MakeSuccess();
    }

    ResultMsg ModelManager::RestoreServicesByState(const std::map<std::string, bool> &preStates) {
        // 按停止前状态恢复：原本运行的启动，原本停止的保持停止
        // 失败仅告警不中断，确保回退流程能继续执行
        for (const auto &kv : preStates) {
            if (kv.second) {
                // 原本在运行，尝试启动
                auto startRet = mCtx.serviceManager->StartService(kv.first);
                if (!startRet.IsDefalutSuccess()) {
                    SLOG_WARN << "Failed to restore service " << kv.first << " to running state: " << startRet.msg;
                }
            }
        }
        return MakeSuccess();
    }

    ResultMsg ModelManager::StartServicesAndWaitRunning(const std::vector<std::string> &serviceNames) {
        // 逐个启动服务并按各自的 keep_alive_time_sec 验证持续运行
        // 每个服务独立验证：启动后等待 keepAliveTimeSec 秒，再检查是否仍活跃
        for (const auto &name : serviceNames) {
            auto startRet = mCtx.serviceManager->StartService(name);
            if (!startRet.IsDefalutSuccess()) {
                return MakeError("Failed to start service " + name + ": " + startRet.msg);
            }

            // 查询服务的 keep_alive_time_sec：0 表示跳过验证
            auto *svc = mCtx.configLoader->GetServiceByName(name);
            uint32_t keepSec = svc ? svc->keepAliveTimeSec : 0;
            if (keepSec == 0) {
                continue;
            }

            // 等待验证时长，确保服务持续运行
            std::this_thread::sleep_for(std::chrono::seconds(keepSec));

            // 检查该服务是否仍处于活跃状态
            if (!mCtx.serviceManager->IsServiceActive(name)) {
                return MakeError("Service " + name + " is not active after " + std::to_string(keepSec) + "s");
            }
        }
        return MakeSuccess();
    }

    ResultMsg ModelManager::ValidateModelName(const std::string &modelName) const {
        if (modelName.empty()) {
            return MakeError("Model name is empty");
        }
        // 禁止使用 .back 结尾的模型名，避免与备份命名冲突
        if (modelName.size() >= 5 && modelName.compare(modelName.size() - 5, 5, ".back") == 0) {
            return MakeError("Model name must not end with '.back': " + modelName);
        }
        return MakeSuccess();
    }

}  // namespace qifeng::scm
