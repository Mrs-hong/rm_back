/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */
#include "common/scmd_types.h"
#include "common/utils/path.h"
#include "common/utils/user.h"
#include "service_manager/service_generator.h"
#include "service_tool/tools_def.h"
#include <filesystem>
#include <sstream>
namespace {  // 工具函数拆分、降低单函数复杂度
    using qifeng::scm::ConfigInfo;
    using qifeng::scm::ServiceDefinition;

    // 将依赖列表格式化为空格分隔的 service 单元名列表
    std::string FormatDependencyList(const std::map<std::string, std::string> &deps, const std::string &unitPrefix) {
        std::ostringstream oss;
        bool first = true;
        for (const auto &dep : deps) {
            // 系统服务暂时跳过
            if (qifeng::scm::tool::IsSystemdService(dep.first)) {
                continue;
            }
            if (!first) {
                oss << " ";
            }
            // 依赖格式：<服务名称, 版本号>，映射为 prefix_service_name.service
            oss << unitPrefix << dep.first << ".service";
            first = false;
        }
        return oss.str();
    }

    // 写入 [Unit] 段
    void WriteUnitSection(std::ostringstream &oss, const ServiceDefinition &def, const std::string &unitPrefix) {
        oss << "[Unit]\n";
        // Description: 服务名称 + 版本号
        oss << "Description=" << def.serviceName;
        if (!def.version.empty()) {
            oss << " " << def.version;
        }
        oss << "\n";

        // After: 依赖服务启动顺序（确保依赖服务先启动）
        // Requires: 强制依赖，依赖服务必须成功启动
        if (!def.dependencies.empty() && def.isUseful) {
            oss << "After=" << FormatDependencyList(def.dependencies, unitPrefix) << "\n";
            oss << "Requires=" << FormatDependencyList(def.dependencies, unitPrefix) << "\n";
        }

        // StartLimitIntervalSec / StartLimitBurst: 60 秒内最多重启 3 次，防止无限循环
        oss << "StartLimitIntervalSec=60s\n";
        oss << "StartLimitBurst=3\n";

        oss << "\n";
    }

    // 写入 [Service] 段：执行配置（Type, ExecStart, WorkingDirectory, User）
    void WriteServiceExecConfig(std::ostringstream &oss, const ServiceDefinition &def) {
        oss << "[Service]\n";
        // CPUAccounting: 启用 CPU 资源计量，记录进程运行时间
        oss << "CPUAccounting=yes\n";
        // Type: 简单进程类型，systemd 认为 ExecStart 启动的进程即为服务主进程
        oss << "Type=simple\n";

        // ExecStart: 可执行文件路径 + 命令行参数
        oss << "ExecStart=" << qifeng::scm::utils::JoinPath(def.currentServiceDir, def.execInfo.command);
        for (const auto &arg : def.execInfo.args) {
            oss << " " << arg;
        }
        oss << "\n";

        // WorkingDirectory: 工作目录
        if (!def.execInfo.workDir.empty()) {
            oss << "WorkingDirectory=" << qifeng::scm::utils::JoinPath(def.currentServiceDir, def.execInfo.workDir)
                << "\n";
        }

        // User: 运行用户，若配置未指定则使用当前系统用户，避免 root 启动被拒绝
        std::string effectiveUser = def.execInfo.user;
        if (effectiveUser.empty()) {
            effectiveUser = qifeng::scm::utils::GetCurrentUserName();
        }
        if (!effectiveUser.empty()) {
            oss << "User=" << effectiveUser << "\n";
        }
    }

    // 写入 [Service] 段：环境变量（env, DATA_DIR, SERVICE_DIR）
    void WriteServiceEnvironment(std::ostringstream &oss, const ServiceDefinition &def, const ConfigInfo &configInfo) {
        // Environment: 用户自定义环境变量
        for (const auto &env : def.execInfo.env) {
            oss << "Environment=" << env << "\n";
        }
        // 依赖模型文件的服务注入模型目录环境变量（变量名来自 scmd.yaml，值为模型目录绝对路径）
        if (def.needModel && !configInfo.modelEnvVar.empty() && !configInfo.modelDir.empty()) {
            oss << "Environment=" << configInfo.modelEnvVar << "=" << configInfo.modelDir << "\n";
        }
    }

    // 写入 [Service] 段：进程控制与资源限制（KillSignal, TimeoutStopSec, Restart, MemoryMax, CPUQuota）
    void WriteServiceResourceConfig(std::ostringstream &oss, const ServiceDefinition &def) {
        // KillSignal: 优雅停止信号（默认 SIGTERM=15）
        oss << "KillSignal=" << def.execInfo.gracefulStopSignal << "\n";

        // TimeoutStopSec: 停止服务超时时间，超时后 systemd 发送 SIGKILL 强制终止
        oss << "TimeoutStopSec=" << def.execInfo.timeoutStopSec << "s\n";

        // Restart: 服务异常退出时自动重启
        oss << "Restart=on-failure\n";
        // RestartSec: 重启间隔 5 秒，避免过快重启消耗资源
        oss << "RestartSec=5\n";

        // 资源限制：内存
        if (def.resourcesInfo.memoryMB > 0) {
            oss << "MemoryMax=" << def.resourcesInfo.memoryMB << "M\n";
        }

        // 资源限制：CPU 配额百分比
        if (def.resourcesInfo.cpuPercent > 0) {
            oss << "CPUQuota=" << def.resourcesInfo.cpuPercent << "%\n";
        }

        oss << "\n";
    }

    // 写入 [Install] 段
    void WriteInstallSection(std::ostringstream &oss) {
        oss << "[Install]\n";
        // WantedBy: 自动启动目标，与 isAutoStart 解耦
        // isAutoStart 控制 scmd init 时是否自动启动，systemd enable/disable 由独立 API 控制
        oss << "WantedBy=multi-user.target\n";
    }

    // 校验输入参数合法性
    qifeng::scm::ResultMsg ValidateParams(const ServiceDefinition &def) {
        // 校验必填字段：服务名称
        if (def.serviceName.empty()) {
            return qifeng::scm::MakeError("Service name is empty");
        }

        // 校验必填字段：可执行命令
        if (def.execInfo.command.empty()) {
            return qifeng::scm::MakeError("Exec command is empty for service: " + def.serviceName);
        }

        // 校验可执行命令路径存在性
        namespace fs = std::filesystem;
        if (!fs::exists(qifeng::scm::utils::JoinPath(def.currentServiceDir, def.execInfo.command))) {
            return qifeng::scm::MakeError("Exec command does not exist: " + def.execInfo.command);
        }

        return qifeng::scm::MakeSuccess();
    }
}  // namespace

namespace qifeng::scm {
    ResultMsg ServiceGenerator::GenerateContent(const ServiceDefinition &serviceDef, const std::string &unitPrefix,
                                                const ConfigInfo &configInfo) {
        try {
            // 参数校验
            auto validateRet = ValidateParams(serviceDef);
            if (!validateRet.IsDefalutSuccess()) {
                return validateRet;
            }

            // 生成 service 文件内容
            std::ostringstream oss;
            WriteUnitSection(oss, serviceDef, unitPrefix);
            WriteServiceExecConfig(oss, serviceDef);
            WriteServiceEnvironment(oss, serviceDef, configInfo);
            WriteServiceResourceConfig(oss, serviceDef);
            WriteInstallSection(oss);
            return ResultMsg {0, oss.str()};
        } catch (const std::exception &e) {
            return MakeError("Failed to generate systemd service file: " + std::string(e.what()));
        }
    }
}  // namespace qifeng::scm