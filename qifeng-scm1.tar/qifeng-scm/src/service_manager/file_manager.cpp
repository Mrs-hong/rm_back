/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */
#include "common/types.h"
#include "service_manager/file_manager.h"

#include "common/utils/file.h"
#include "common/utils/path.h"
#include "common/utils/path_migration.h"
#include "common/utils/symlink.h"
#include "common/utils/user.h"
#include "qifeng_framework/common/logger.h"

#include <filesystem>
#include <fstream>
#include <sstream>
#include <yaml-cpp/yaml.h>

namespace fs = std::filesystem;

namespace qifeng::scm {

    namespace {
        // 统一拷贝文件或目录到目标路径
        // - 目录：递归拷贝（CopyDirectory 内部自动创建目标目录）
        // - 文件：先确保目标父目录存在，再覆盖拷贝
        // 设计目的：up_detail.yaml 的 replace/add 列表既可填目录也可填文件，
        //           统一入口避免调用方逐处判断类型
        ResultMsg CopyEntry(const std::string &src, const std::string &dst) {
            std::error_code ec;
            if (!fs::exists(src, ec)) {
                return MakeError("Source does not exist: " + src);
            }
            if (fs::is_directory(src)) {
                return utils::CopyDirectory(src, dst);
            }
            // 文件：确保目标父目录存在后拷贝（与目录路径 create_directories 行为对齐）
            fs::path dstPath(dst);
            fs::path parent = dstPath.parent_path();
            if (!parent.empty() && !fs::exists(parent, ec)) {
                fs::create_directories(parent, ec);
                if (ec) {
                    return MakeError("Failed to create parent directory: " + parent.string() + ", " + ec.message());
                }
            }
            fs::copy_file(src, dst, fs::copy_options::overwrite_existing, ec);
            if (ec) {
                return MakeError("Failed to copy file " + src + " to " + dst + ": " + ec.message());
            }
            return MakeSuccess();
        }
    }  // namespace

    bool FileDirInfo::operator==(const FileDirInfo &other) const {
        return configDir == other.configDir && serviceDir == other.serviceDir && dataDir == other.dataDir &&
               backupDir == other.backupDir && logsDir == other.logsDir && tempDir == other.tempDir;
    }

    FileManager::FileManager(FileDirInfo &&dirConfig) : mCurDirConfig(std::move(dirConfig)) {
    }

    ResultMsg FileManager::InitFileDir() {
        // 创建 .config 目录
        auto ret = utils::CreateDirectory(mCurDirConfig.configDir);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create config dir: " + ret.msg);
        }

        // 创建 .service 目录
        ret = utils::CreateDirectory(mCurDirConfig.serviceDir);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create service dir: " + ret.msg);
        }

        // 创建 .service/.init 子目录
        ret = utils::CreateDirectory(GetServiceInitDir());
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create service init dir: " + ret.msg);
        }

        // 创建 .data 目录
        ret = utils::CreateDirectory(mCurDirConfig.dataDir);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create data dir: " + ret.msg);
        }

        // 创建 .backup 目录
        ret = utils::CreateDirectory(mCurDirConfig.backupDir);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create backup dir: " + ret.msg);
        }

        // 创建 .logs 目录
        ret = utils::CreateDirectory(mCurDirConfig.logsDir);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create logs dir: " + ret.msg);
        }

        // 创建 .temp 目录
        ret = utils::CreateDirectory(mCurDirConfig.tempDir);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create temp dir: " + ret.msg);
        }

        // 启动时将历史 <serviceDir>/nginx 迁移到 <serviceDir>/.nginx，
        // 保证升级部署后存量 nginx 目录自动改名（与正常服务目录区分、被扫描跳过）
        EnsureNginxDirMigrated();

        return MakeSuccess();
    }

    // NOLINTBEGIN(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg FileManager::MigrateFileDir(const FileDirInfo &newDirConfig) {
        // 验证新配置与旧配置不同
        if (mCurDirConfig == newDirConfig) {
            return MakeWarning("New directory config is the same as current config");
        }

        // 移动各目录到新位置
        if (fs::exists(mCurDirConfig.configDir)) {
            auto ret = utils::MoveDirectory(mCurDirConfig.configDir, newDirConfig.configDir);
            if (!ret.IsDefalutSuccess()) {
                return MakeError("Failed to migrate config dir: " + ret.msg);
            }
        }

        if (fs::exists(mCurDirConfig.serviceDir)) {
            auto ret = utils::MoveDirectory(mCurDirConfig.serviceDir, newDirConfig.serviceDir);
            if (!ret.IsDefalutSuccess()) {
                return MakeError("Failed to migrate service dir: " + ret.msg);
            }
        }

        if (fs::exists(mCurDirConfig.dataDir)) {
            auto ret = utils::MoveDirectory(mCurDirConfig.dataDir, newDirConfig.dataDir);
            if (!ret.IsDefalutSuccess()) {
                return MakeError("Failed to migrate data dir: " + ret.msg);
            }
        }

        if (fs::exists(mCurDirConfig.backupDir)) {
            auto ret = utils::MoveDirectory(mCurDirConfig.backupDir, newDirConfig.backupDir);
            if (!ret.IsDefalutSuccess()) {
                return MakeError("Failed to migrate backup dir: " + ret.msg);
            }
        }

        if (fs::exists(mCurDirConfig.logsDir)) {
            auto ret = utils::MoveDirectory(mCurDirConfig.logsDir, newDirConfig.logsDir);
            if (!ret.IsDefalutSuccess()) {
                return MakeError("Failed to migrate logs dir: " + ret.msg);
            }
        }

        // 更新目录配置
        mCurDirConfig = newDirConfig;

        // 确保 .init 子目录存在
        auto ret = utils::CreateDirectory(GetServiceInitDir());
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create init dir after migration: " + ret.msg);
        }

        return MakeSuccess();
    }
    // NOLINTEND(readability-function-size, readability-function-cognitive-complexity)

    ResultMsg FileManager::DeleteFileDir() {
        // 先删除所有 systemd 软链接
        auto serviceFiles = GetAllServiceFilesList();
        for (const auto &fileName : serviceFiles) {
            utils::DeleteSymbolicLink(utils::JoinPath(SystemdUnitDir, fileName));
        }

        // 删除各目录
        utils::ForceDeleteDirectory(mCurDirConfig.serviceDir);
        utils::ForceDeleteDirectory(mCurDirConfig.dataDir);
        utils::ForceDeleteDirectory(mCurDirConfig.backupDir);
        utils::ForceDeleteDirectory(mCurDirConfig.logsDir);

        return MakeSuccess();
    }

    // --- 软件包管理------

    ResultMsg FileManager::InstallSoftwarePackage(const std::string &serviceName, const std::string &softwareDir) {
        // 检查服务是否已安装
        std::string serviceDir = GetServiceDir(serviceName);
        if (fs::exists(serviceDir)) {
            return MakeError("Service already installed: " + serviceName);
        }

        // 验证软件包完整性
        std::string softwarePath = utils::JoinPath(softwareDir, serviceName);
        auto ret = VerifySoftwarePackage(softwarePath);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Software package verification failed: " + ret.msg);
        }

        // 解包路径和目标服务路径不相同则复制软件包到服务目录
        // 使用拷贝而非移动：避免安装/升级失败回退时临时目录中的源（可能来自用户目录）被链式丢失
        if (!utils::IsSamePath(softwarePath, serviceDir).IsDefalutSuccess()) {
            auto copyRet = utils::CopyDirectory(softwarePath, serviceDir);
            if (!copyRet.IsDefalutSuccess()) {
                // 失败时清理已创建的目录
                utils::ForceDeleteDirectory(serviceDir);
                return MakeError("Failed to install software package: " + copyRet.msg);
            }
        }

        // 设置服务目录权限
        ret = utils::SetFilePermission(serviceDir, utils::GetCurrentUserName());
        if (!ret.IsDefalutSuccess()) {
            utils::ForceDeleteDirectory(serviceDir);
            return MakeError("Failed to set service directory permission: " + ret.msg);
        }

        // 验证安装后结构
        std::string installedYaml = utils::JoinPath(serviceDir, ServiceYamlName);
        if (!fs::exists(installedYaml)) {
            utils::ForceDeleteDirectory(serviceDir);
            return MakeError("Installed package missing service.yaml");
        }

        return MakeSuccess();
    }

    std::string FileManager::GetServiceWDir(const std::string &serviceName) const {
        return GetServiceDir(serviceName);
    }

    std::vector<std::string> FileManager::GetAllServicesList() {
        std::vector<std::string> services;
        std::string serviceRoot = mCurDirConfig.serviceDir;

        if (!fs::exists(serviceRoot)) {
            return services;
        }

        std::error_code ec;
        for (const auto &entry : fs::directory_iterator(serviceRoot, ec)) {
            if (!entry.is_directory()) {
                continue;
            }

            std::string dirName = entry.path().filename().string();

            // 跳过以 . 开头的目录（如 .init、.nginx）
            if (!dirName.empty() && dirName.front() == '.') {
                continue;
            }

            // 检查是否包含 service.yaml
            std::string yamlPath = utils::JoinPath(entry.path().string(), ServiceYamlName);
            if (fs::exists(yamlPath)) {
                services.push_back(dirName);
            }
        }

        return services;
    }

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg FileManager::UpgradeSoftwarePackage(const std::string &serviceName, const std::string &softwareDir) {
        std::string serviceDir = GetServiceDir(serviceName);

        // 检查服务已安装
        if (!fs::exists(serviceDir)) {
            return MakeError("Service not installed: " + serviceName);
        }

        // 与 InstallSoftwarePackage 保持一致：实际软件包在 softwareDir/serviceName 子目录下
        std::string actualSoftwareDir = utils::JoinPath(softwareDir, serviceName);

        // 备份旧版本（排除数据目录）
        auto ret = BackupOldVersion(serviceName);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to backup old version: " + ret.msg);
        }

        // 验证新软件包
        ret = VerifySoftwarePackage(actualSoftwareDir);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("New software package verification failed: " + ret.msg);
        }

        // 读取旧服务的数据目录名
        std::string dataDirName = ReadServiceDataDirName(serviceName);

        // 升级前先将旧数据目录备份到临时位置，防止 CopyDirectory 覆盖
        std::string oldDataDir = utils::JoinPath(serviceDir, dataDirName);
        std::string oldDataBackup = utils::JoinPath(GetBackupDir(serviceName), ".data_backup");
        bool hasOldData = false;
        if (!dataDirName.empty() && fs::exists(oldDataDir)) {
            hasOldData = true;
            if (fs::exists(oldDataBackup)) {
                utils::ForceDeleteDirectory(oldDataBackup);
            }
            auto backupRet = utils::CopyDirectory(oldDataDir, oldDataBackup);
            if (!backupRet.IsDefalutSuccess()) {
                return MakeError("Failed to backup old data directory: " + backupRet.msg);
            }
        }

        // 删除旧服务文件（保留数据目录）
        ret = ClearDirectoryContentsExclude(serviceDir, dataDirName);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to clear old service files: " + ret.msg);
        }

        // 复制新软件包到服务目录
        auto copyRet = utils::CopyDirectory(actualSoftwareDir, serviceDir);
        if (!copyRet.IsDefalutSuccess()) {
            // 复制失败，尝试回滚
            RollbackSoftwarePackage(serviceName);
            return MakeError("Failed to copy new software package: " + copyRet.msg);
        }

        // 用旧数据目录覆盖新包中的默认数据目录，确保数据复用
        if (hasOldData) {
            std::string newDataDir = utils::JoinPath(serviceDir, dataDirName);
            if (fs::exists(newDataDir)) {
                utils::ForceDeleteDirectory(newDataDir);
            }
            auto restoreRet = utils::CopyDirectory(oldDataBackup, newDataDir);
            if (!restoreRet.IsDefalutSuccess()) {
                SLOG_ERROR << "Failed to restore old data directory: " << restoreRet.msg;
            }
            utils::ForceDeleteDirectory(oldDataBackup);
        }

        // 验证安装后结构
        std::string installedYaml = utils::JoinPath(serviceDir, ServiceYamlName);
        if (!fs::exists(installedYaml)) {
            RollbackSoftwarePackage(serviceName);
            return MakeError("Upgraded package missing service.yaml");
        }

        return MakeSuccess();
    }

    ResultMsg FileManager::RemoveSoftwarePackage(const std::string &serviceName) {
        std::string serviceDir = GetServiceDir(serviceName);

        // 检查服务已安装
        if (!fs::exists(serviceDir)) {
            return MakeError("Service not installed: " + serviceName);
        }

        // 删除 .init 中的 service 文件
        DeleteServiceFile(serviceName);

        // 删除 systemd 软链接
        DeleteServiceSymlink(serviceName);

        // 删除服务目录
        auto ret = utils::ForceDeleteDirectory(serviceDir);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to remove service directory: " + ret.msg);
        }

        return MakeSuccess();
    }

    ResultMsg FileManager::RollbackSoftwarePackage(const std::string &serviceName) {
        std::string backupDir = GetBackupDir(serviceName);
        std::string serviceDir = GetServiceDir(serviceName);

        // 检查备份目录存在
        if (!fs::exists(backupDir)) {
            return MakeError("Backup not found for service: " + serviceName);
        }

        // 读取当前服务的数据目录名
        std::string dataDirName = ReadServiceDataDirName(serviceName);

        // 删除当前服务文件（保留数据目录）
        auto ret = ClearDirectoryContentsExclude(serviceDir, dataDirName);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to clear current service files during rollback: " + ret.msg);
        }

        // 将备份内容复制回服务目录
        auto copyRet = utils::CopyDirectory(backupDir, serviceDir);
        if (!copyRet.IsDefalutSuccess()) {
            return MakeError("Failed to restore from backup: " + copyRet.msg);
        }

        return MakeSuccess();
    }

    ResultMsg FileManager::CleanBackup(const std::string &serviceName) {
        std::string backupDir = GetBackupDir(serviceName);

        if (!fs::exists(backupDir)) {
            return MakeWarning("Backup not found for service: " + serviceName);
        }

        return utils::ForceDeleteDirectory(backupDir);
    }

    // --- service文件管理------

    ResultMsg FileManager::CreateServiceFile(const std::string &fileData, const std::string &serviceName) {
        // 确保 .init 目录存在
        auto ret = utils::CreateDirectory(GetServiceInitDir());
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create init directory: " + ret.msg);
        }

        std::string filePath = GetServiceInitFilePath(serviceName);

        // 检查文件是否已存在
        if (fs::exists(filePath)) {
            return MakeError("Service file already exists: " + filePath);
        }

        // 写入文件
        std::ofstream ofs(filePath);
        if (!ofs.is_open()) {
            return MakeError("Failed to create service file: " + filePath);
        }
        ofs << fileData;
        ofs.close();

        // 设置服务文件权限
        ret = utils::SetFilePermission(filePath, utils::GetCurrentUserName());
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to set service file permission: " + ret.msg);
        }

        return MakeSuccess();
    }

    std::vector<std::string> FileManager::GetAllServiceFilesList() {
        std::vector<std::string> files;
        std::string initDir = GetServiceInitDir();

        if (!fs::exists(initDir)) {
            return files;
        }

        std::error_code ec;
        for (const auto &entry : fs::directory_iterator(initDir, ec)) {
            if (!entry.is_regular_file()) {
                continue;
            }

            std::string filename = entry.path().filename().string();

            // 只返回 scmd_*.service 格式的文件
            if (filename.find(ServiceFilePrefix) == 0 && filename.size() >= strlen(ServiceFileSuffix) &&
                filename.substr(filename.size() - strlen(ServiceFileSuffix)) == ServiceFileSuffix) {
                files.push_back(filename);
            }
        }

        return files;
    }

    ResultMsg FileManager::FreshServiceFile(const std::string &newFileData, const std::string &serviceName) {
        std::string filePath = GetServiceInitFilePath(serviceName);

        if (!fs::exists(filePath)) {
            return MakeError("Service file not found: " + filePath);
        }

        // 覆盖写入新内容
        std::ofstream ofs(filePath, std::ios::trunc);
        if (!ofs.is_open()) {
            return MakeError("Failed to open service file for writing: " + filePath);
        }
        ofs << newFileData;
        ofs.close();

        return MakeSuccess();
    }

    std::string FileManager::GetServiceFileContent(const std::string &serviceName) {
        std::string filePath = GetServiceInitFilePath(serviceName);

        if (!fs::exists(filePath)) {
            return "";
        }

        std::ifstream ifs(filePath);
        if (!ifs.is_open()) {
            return "";
        }

        std::ostringstream oss;
        oss << ifs.rdbuf();
        return oss.str();
    }

    ResultMsg FileManager::DeleteServiceFile(const std::string &serviceName) {
        std::string filePath = GetServiceInitFilePath(serviceName);

        if (!fs::exists(filePath)) {
            return MakeWarning("Service file not found: " + filePath);
        }

        std::error_code ec;
        fs::remove(filePath, ec);
        if (ec) {
            return MakeError("Failed to delete service file: " + filePath + ", " + ec.message());
        }

        return MakeSuccess();
    }

    // --- 软链接管理------

    ResultMsg FileManager::CreateServiceSymlink(const std::string &serviceName) {
        std::string initFilePath = GetServiceInitFilePath(serviceName);

        // 检查 .init 文件存在
        if (!fs::exists(initFilePath)) {
            return MakeError("Service init file not found: " + initFilePath);
        }

        // 构造软链接路径和目标路径
        std::string linkPath = utils::JoinPath(SystemdUnitDir, ServiceFilePrefix + serviceName + ServiceFileSuffix);
        std::string targetPath = utils::GetAbsolutePath(initFilePath);

        return utils::CreateSymbolicLink(targetPath, linkPath);
    }

    ResultMsg FileManager::DeleteServiceSymlink(const std::string &serviceName) {
        std::string linkPath = utils::JoinPath(SystemdUnitDir, ServiceFilePrefix + serviceName + ServiceFileSuffix);

        return utils::DeleteSymbolicLink(linkPath);
    }

    ResultMsg FileManager::FreshServiceSymlink(const std::string &serviceName) {
        std::string linkPath = utils::JoinPath(SystemdUnitDir, ServiceFilePrefix + serviceName + ServiceFileSuffix);
        // 检查软链接是否存在
        ResultMsg ret;
        if (fs::exists(linkPath)) {
            ret = DeleteServiceSymlink(serviceName);
        }
        if (!ret.IsDefalutSuccess()) {
            return ret;
        }
        ret = CreateServiceSymlink(serviceName);
        if (!ret.IsDefalutSuccess()) {
            return ret;
        }
        return ret;
    }

    // --- 数据目录管理------

    ResultMsg FileManager::MigrateServiceData(const std::string &serviceName, const std::string &dataSubDir) {
        std::string serviceDir = GetServiceDir(serviceName);
        std::string srcDataPath = utils::JoinPath(serviceDir, dataSubDir);

        // 检查源数据目录存在
        if (!fs::exists(srcDataPath)) {
            return MakeError("Source data directory does not exist: " + srcDataPath);
        }

        // 创建 .data/xxxx/ 目标目录
        std::string dataDir = GetDataDir(serviceName);
        auto ret = utils::CreateDirectory(dataDir);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create data directory: " + ret.msg);
        }

        // 移动数据目录到 .data/xxxx/dataSubDir
        std::string dstDataPath = utils::JoinPath(dataDir, dataSubDir);

        // 确保目标父目录存在
        fs::path dstParentPath = fs::path(dstDataPath).parent_path();
        if (!dstParentPath.empty()) {
            ret = utils::CreateDirectory(dstParentPath.string());
            if (!ret.IsDefalutSuccess()) {
                return MakeError("Failed to create data subdirectory: " + ret.msg);
            }
        }

        ret = utils::MoveDirectory(srcDataPath, dstDataPath);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to migrate data directory: " + ret.msg);
        }

        // 在原位置创建软链接指向新位置，保持兼容性
        std::string absDstPath = utils::GetAbsolutePath(dstDataPath);
        ret = utils::CreateSymbolicLink(absDstPath, srcDataPath);
        if (!ret.IsDefalutSuccess()) {
            // 软链接创建失败，尝试将数据移回
            utils::MoveDirectory(dstDataPath, srcDataPath);
            return MakeError("Failed to create symlink after migration: " + ret.msg);
        }

        return MakeSuccess();
    }

    // --- 查询接口------

    std::string FileManager::GetServiceConfigPath(const std::string &serviceName) const {
        return utils::JoinPath(GetServiceDir(serviceName), ServiceYamlName);
    }

    const FileDirInfo &FileManager::GetCurDirConfig() const {
        return mCurDirConfig;
    }

    // --- 私有路径辅助方法------

    std::string FileManager::GetServiceInitDir() const {
        return utils::JoinPath(mCurDirConfig.serviceDir, InitDirName);
    }

    std::string FileManager::GetServiceInitFilePath(const std::string &serviceName) const {
        return utils::JoinPath(GetServiceInitDir(), ServiceFilePrefix + serviceName + ServiceFileSuffix);
    }

    std::string FileManager::GetServiceDir(const std::string &serviceName) const {
        return utils::JoinPath(mCurDirConfig.serviceDir, serviceName);
    }

    std::string FileManager::GetBackupDir(const std::string &serviceName) const {
        return utils::JoinPath(mCurDirConfig.backupDir, serviceName);
    }

    std::string FileManager::GetDataDir(const std::string &serviceName) const {
        return utils::JoinPath(mCurDirConfig.dataDir, serviceName);
    }

    // --- 私有工具方法------

    ResultMsg FileManager::VerifySoftwarePackage(const std::string &softwareDir) {
        // 检查软件包目录存在
        if (!fs::exists(softwareDir)) {
            return MakeError("Software package directory does not exist: " + softwareDir);
        }

        // 检查 service.yaml 存在
        std::string yamlPath = utils::JoinPath(softwareDir, ServiceYamlName);
        if (!fs::exists(yamlPath)) {
            return MakeError("Software package missing " + std::string(ServiceYamlName));
        }

        // 检查 service.yaml 可读取
        std::ifstream ifs(yamlPath);
        if (!ifs.is_open()) {
            return MakeError("Cannot read " + std::string(ServiceYamlName) + " in package");
        }
        ifs.close();

        // 基本YAML格式验证
        try {
            YAML::LoadFile(yamlPath);
        } catch (const YAML::Exception &e) {
            return MakeError("Invalid YAML format in " + std::string(ServiceYamlName) + ": " + e.what());
        }

        return MakeSuccess();
    }

    ResultMsg FileManager::BackupOldVersion(const std::string &serviceName) {
        std::string serviceDir = GetServiceDir(serviceName);
        std::string backupDir = GetBackupDir(serviceName);

        // 检查服务目录存在
        if (!fs::exists(serviceDir)) {
            return MakeError("Service directory does not exist: " + serviceDir);
        }

        // 如果备份已存在，先清理
        if (fs::exists(backupDir)) {
            auto ret = utils::ForceDeleteDirectory(backupDir);
            if (!ret.IsDefalutSuccess()) {
                return MakeError("Failed to clean existing backup: " + ret.msg);
            }
        }

        // 读取数据目录名，备份时排除数据目录
        std::string dataDirName = ReadServiceDataDirName(serviceName);

        // 复制服务目录到备份目录（排除数据目录）
        return CopyDirectoryExcludeSubDir(serviceDir, backupDir, dataDirName);
    }

    std::string FileManager::ReadServiceDataDirName(const std::string &serviceName) const {
        std::string yamlPath = utils::JoinPath(GetServiceDir(serviceName), ServiceYamlName);

        if (!fs::exists(yamlPath)) {
            return "";
        }

        try {
            YAML::Node config = YAML::LoadFile(yamlPath);

            // 读取 execution.dataDir 字段
            if (config["execution"] && config["execution"]["dataDir"]) {
                return config["execution"]["dataDir"].as<std::string>("");
            }
        } catch (const YAML::Exception &) {
            // YAML 解析失败，返回空字符串
        }

        return "";
    }

    // NOLINTBEGIN(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg FileManager::CopyDirectoryExcludeSubDir(const std::string &src, const std::string &dst,
                                                      const std::string &excludeSubDir) {
        // 如果没有需要排除的子目录，直接使用 utils::CopyDirectory
        if (excludeSubDir.empty()) {
            return utils::CopyDirectory(src, dst);
        }

        // 解析排除路径的第一级目录名
        // 例如 "db/data" 的第一级是 "db"
        std::string firstLevelDir = excludeSubDir;
        size_t slashPos = excludeSubDir.find('/');
        if (slashPos != std::string::npos) {
            firstLevelDir = excludeSubDir.substr(0, slashPos);
        }

        // 创建目标目录
        auto ret = utils::CreateDirectory(dst);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create destination directory: " + dst);
        }

        // 遍历源目录，逐项复制（排除指定子目录）
        std::error_code ec;
        for (const auto &entry : fs::directory_iterator(src, ec)) {
            const auto &path = entry.path();
            std::string filename = path.filename().string();

            // 跳过排除的子目录
            if (filename == firstLevelDir && entry.is_directory()) {
                continue;
            }

            fs::path destPath = fs::path(dst) / filename;

            if (entry.is_directory()) {
                ret = utils::CopyDirectory(path.string(), destPath.string());
                if (!ret.IsDefalutSuccess()) {
                    return ret;
                }
            } else {
                fs::copy_file(path, destPath, fs::copy_options::overwrite_existing, ec);
                if (ec) {
                    return MakeError("Failed to copy file: " + path.string() + " -> " + destPath.string() + ", " +
                                     ec.message());
                }
            }
        }

        return MakeSuccess();
    }
    // NOLINTEND(readability-function-size, readability-function-cognitive-complexity)

    ResultMsg FileManager::ClearDirectoryContentsExclude(const std::string &dir, const std::string &excludeSubDir) {
        // 如果没有需要排除的子目录，直接使用 utils::ClearDirectoryContents
        if (excludeSubDir.empty()) {
            return utils::ClearDirectoryContents(dir);
        }

        // 解析排除路径的第一级目录名
        std::string firstLevelDir = excludeSubDir;
        size_t slashPos = excludeSubDir.find('/');
        if (slashPos != std::string::npos) {
            firstLevelDir = excludeSubDir.substr(0, slashPos);
        }

        // 遍历目录，逐项删除（排除指定子目录）
        std::error_code ec;
        if (!fs::exists(dir, ec)) {
            return MakeSuccess();
        }

        for (const auto &entry : fs::directory_iterator(dir, ec)) {
            const auto &path = entry.path();
            std::string filename = path.filename().string();

            // 跳过排除的子目录
            if (filename == firstLevelDir && entry.is_directory()) {
                continue;
            }

            fs::remove_all(path, ec);
            if (ec) {
                return MakeError("Failed to remove: " + path.string() + ", " + ec.message());
            }
        }

        return MakeSuccess();
    }

    // --- 前端 nginx 管理 ---

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg FileManager::UninstallFrontend(const std::string &serviceName) {
        if (serviceName.empty()) {
            return MakeError("Service name is empty");
        }

        // 先将旧的 <serviceDir>/nginx 迁移到 <serviceDir>/.nginx，保证后续读取路径一致
        EnsureNginxDirMigrated();

        // 清理 conf.d 和 snippets 中由 scm 创建的软链（目标指向 service/nginx/ 目录）
        std::error_code ec;
        std::string nginxDst = GetNginxDir();
        auto targetDirs = {NginxSystemConfDir, NginxSystemSnippetsDir};

        for (const auto &dir : targetDirs) {
            if (!fs::exists(dir)) {
                continue;
            }
            for (const auto &entry : fs::directory_iterator(dir, ec)) {
                if (ec) {
                    continue;
                }
                if (!fs::is_symlink(entry.path(), ec)) {
                    continue;
                }
                // 检查软链目标是否指向 service/nginx 目录
                auto target = fs::read_symlink(entry.path(), ec);
                if (ec) {
                    continue;
                }
                if (target.string().find(nginxDst) != std::string::npos) {
                    fs::remove(entry.path(), ec);
                    if (ec) {
                        SLOG_WARN << "Failed to remove nginx symlink: " << entry.path().string() << ": "
                                  << ec.message();
                    } else {
                        SLOG_INFO << "Removed nginx symlink: " << entry.path().string();
                    }
                }
            }
        }

        return MakeSuccess();
    }

    std::string FileManager::GetFrontendDir(const std::string &serviceName) const {
        return utils::JoinPath(GetServiceDir(serviceName), "nginx");
    }

    // --- 独立 nginx 配置管理 ---

    std::string FileManager::GetNginxDir() const {
        return utils::JoinPath(mCurDirConfig.serviceDir, ".nginx");
    }

    void FileManager::EnsureNginxDirMigrated() {
        // 兼容历史版本：将旧的 <serviceDir>/nginx 迁移到新的 <serviceDir>/.nginx
        std::string oldDir = utils::JoinPath(mCurDirConfig.serviceDir, "nginx");
        std::string newDir = GetNginxDir();  // 即 serviceDir/.nginx

        std::error_code ec;
        bool oldExists = fs::exists(oldDir, ec);
        bool newExists = fs::exists(newDir, ec);

        if (oldExists && newExists) {
            // 边界情况：新旧目录同时存在，保留现状不动，仅告警避免数据丢失
            SLOG_WARN << "Both old nginx dir and new .nginx dir exist, leaving as-is: old=" << oldDir
                      << ", new=" << newDir;
            return;
        }

        if (!oldExists || newExists) {
            // 无需迁移：旧目录不存在，或新目录已存在
            return;
        }

        // 旧目录存在且新目录不存在，执行迁移：nginx -> .nginx
        fs::rename(oldDir, newDir, ec);
        if (ec) {
            SLOG_WARN << "Failed to migrate nginx dir from " << oldDir << " to " << newDir
                      << ": " << ec.message();
            return;
        }
        SLOG_INFO << "Migrated nginx dir from " << oldDir << " to " << newDir;

        // 同步重定向 /etc/nginx/conf.d 与 /etc/nginx/snippets 中指向旧 nginx 目录的软链，
        // 否则迁移后这些软链会变成悬空链（target 仍指向 <serviceDir>/nginx/...）
        // 复用 utils::RepointNginxSymlinks（按 scm_ 前缀过滤，仅处理本系统管理的软链）
        auto repointRet = utils::RepointNginxSymlinks(oldDir, newDir);
        if (!repointRet.IsDefalutSuccess()) {
            SLOG_WARN << "RepointNginxSymlinks failed during nginx dir migration: " << repointRet.msg;
        }
    }

    // === nginx 软链管理辅助方法 ===
    // 统一 InitNginx/ResetNginx/SetNginxWaiting/SetNginxNormal 中重复的软链增删模式。

    ResultMsg FileManager::CreateSymlinkForce(const std::string &targetPath, const std::string &linkPath) {
        std::error_code ec;
        // 移除已存在的同名文件/软链（软链可能已失效，需 is_symlink 兜底判断）
        if (fs::exists(linkPath, ec) || fs::is_symlink(linkPath, ec)) {
            fs::remove(linkPath, ec);
            if (ec) {
                SLOG_WARN << "Failed to remove existing link: " << linkPath << ": " << ec.message();
                return MakeError("Failed to remove existing link " + linkPath + ": " + ec.message());
            }
        }
        ec.clear();
        fs::create_symlink(targetPath, linkPath, ec);
        if (ec) {
            SLOG_WARN << "Failed to create symlink: " << linkPath << " -> " << targetPath << ": " << ec.message();
            return MakeError("Failed to create symlink " + linkPath + " -> " + targetPath + ": " + ec.message());
        }
        SLOG_INFO << "Created symlink: " << linkPath << " -> " << targetPath;
        return MakeSuccess();
    }

    // NOLINTNEXTLINE(readability-function-cognitive-complexity)
    ResultMsg FileManager::InstallScmConfSymlinks(const std::string &nginxDst) {
        std::string confDir = utils::JoinPath(nginxDst, "conf.d");
        if (!fs::exists(confDir)) {
            return MakeSuccess();  // 无 conf.d 视为无需安装
        }

        // 确保系统 nginx 目录存在
        std::error_code ec;
        fs::create_directories(NginxSystemConfDir, ec);
        fs::create_directories(NginxSystemSnippetsDir, ec);

        int failCount = 0;
        for (const auto &entry : fs::directory_iterator(confDir, ec)) {
            if (ec) {
                break;
            }
            if (!entry.is_regular_file() || entry.path().extension() != ".conf") {
                continue;
            }
            std::string filename = entry.path().filename().string();
            // waiting.conf 仅由 SetNginxWaiting 使用，正常配置不安装
            if (filename == NginxWaitingConfName) {
                continue;
            }
            // 按前缀路由：server_ → conf.d；snippet_ → snippets（均用原名）
            std::string linkPath;
            if (filename.find(NginxServerPrefix) == 0) {
                linkPath = utils::JoinPath(NginxSystemConfDir, filename);
            } else if (filename.find(NginxSnippetPrefix) == 0) {
                linkPath = utils::JoinPath(NginxSystemSnippetsDir, filename);
            } else {
                SLOG_WARN << "Skipping unrecognized conf (prefix must be server_ or snippet_): " << filename;
                continue;
            }
            std::string targetPath = utils::GetAbsolutePath(entry.path().string());
            auto ret = CreateSymlinkForce(targetPath, linkPath);
            if (!ret.IsDefalutSuccess()) {
                ++failCount;  // CreateSymlinkForce 已 SLOG_WARN
            }
        }

        if (failCount > 0) {
            return MakeWarning("Failed to create " + std::to_string(failCount) + " nginx conf symlinks");
        }
        return MakeSuccess();
    }

    ResultMsg FileManager::CreateFrontendSymlink(const std::string &nginxDst) {
        std::string frontendSrc = utils::JoinPath(nginxDst, "frontend");
        if (!fs::exists(frontendSrc)) {
            return MakeSuccess();  // 无 frontend 目录，跳过
        }
        std::string frontendTarget = utils::GetAbsolutePath(frontendSrc);
        return CreateSymlinkForce(frontendTarget, NginxFrontendLinkPath);
    }

    ResultMsg FileManager::RemoveWaitingConfLink() {
        std::error_code ec;
        if (!fs::exists(NginxWaitingLinkPath, ec) && !fs::is_symlink(NginxWaitingLinkPath, ec)) {
            SLOG_INFO << "No waiting.conf found, nothing to remove";
            return MakeSuccess();
        }
        fs::remove(NginxWaitingLinkPath, ec);
        if (ec) {
            SLOG_WARN << "Failed to remove waiting.conf: " << ec.message();
            return MakeError("Failed to remove waiting.conf: " + ec.message());
        }
        SLOG_INFO << "Removed waiting.conf";
        return MakeSuccess();
    }

    ResultMsg FileManager::RemoveFrontendLink() {
        std::error_code ec;
        if (!fs::exists(NginxFrontendLinkPath, ec) && !fs::is_symlink(NginxFrontendLinkPath, ec)) {
            return MakeSuccess();
        }
        fs::remove(NginxFrontendLinkPath, ec);
        if (ec) {
            SLOG_WARN << "Failed to remove frontend link: " << ec.message();
            return MakeError("Failed to remove frontend link: " + ec.message());
        }
        SLOG_INFO << "Removed frontend link";
        return MakeSuccess();
    }

    void FileManager::RollbackNginxInstall(const std::string &nginxDst, const std::string &nginxBackup,
                                           bool hadExistingNginx) {
        // 清理已创建的系统软链（未创建则为 no-op）；恢复系统默认站点（未禁用则为 no-op）
        UninstallFrontend("scm");
        RestoreSystemDefaultSite();
        utils::ForceDeleteDirectory(nginxDst);
        if (hadExistingNginx && !nginxBackup.empty() && fs::exists(nginxBackup)) {
            utils::CopyDirectory(nginxBackup, nginxDst);
        }
    }

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg FileManager::InitNginx(const std::string &srcPath) {
        // 先将旧的 <serviceDir>/nginx 迁移到 <serviceDir>/.nginx，保证后续读取路径一致
        EnsureNginxDirMigrated();

        if (!fs::exists(srcPath)) {
            return MakeError("Source path does not exist: " + srcPath);
        }

        // 识别 nginx 根目录：优先直接包含 conf.d/frontend 的目录，
        // 其次 srcPath/nginx，最后兼容 srcPath/frontend
        auto hasNginxStructure = [](const std::string &path) -> bool {
            return fs::exists(utils::JoinPath(path, "conf.d")) || fs::exists(utils::JoinPath(path, "frontend"));
        };

        std::string nginxRootSrc;
        if (hasNginxStructure(srcPath)) {
            nginxRootSrc = srcPath;
        } else {
            std::string nginxSubDir = utils::JoinPath(srcPath, "nginx");
            if (fs::exists(nginxSubDir) && hasNginxStructure(nginxSubDir)) {
                nginxRootSrc = nginxSubDir;
            } else {
                std::string frontendSubDir = utils::JoinPath(srcPath, "frontend");
                if (fs::exists(frontendSubDir)) {
                    nginxRootSrc = frontendSubDir;
                } else {
                    return MakeError("No valid nginx structure (conf.d/frontend) found in: " + srcPath);
                }
            }
        }

        std::string nginxDst = GetNginxDir();

        // 清理旧的系统 conf 软链/文件（使用 scm_ 前缀），避免后续创建软链时冲突
        auto uninstallResult = UninstallFrontend("scm");
        if (!uninstallResult.IsDefalutSuccess()) {
            SLOG_WARN << "Failed to uninstall old nginx conf: " << uninstallResult.msg;
        }

        // 备份已有 nginx 目录（用于回退），并清除当前目录
        bool hadExistingNginx = fs::exists(nginxDst);
        std::string nginxBackup;
        if (hadExistingNginx) {
            nginxBackup = utils::JoinPath(mCurDirConfig.backupDir, "nginx_backup");
            if (fs::exists(nginxBackup)) {
                utils::ForceDeleteDirectory(nginxBackup);
            }
            auto backupRet = utils::CopyDirectory(nginxDst, nginxBackup);
            if (!backupRet.IsDefalutSuccess()) {
                SLOG_WARN << "Failed to backup existing nginx directory: " << backupRet.msg;
            }
            auto delRet = utils::ForceDeleteDirectory(nginxDst);
            if (!delRet.IsDefalutSuccess()) {
                return MakeError("Failed to clean existing nginx directory: " + delRet.msg);
            }
        }

        // 创建 nginx 目录并按原结构拷贝源内容
        auto ret = utils::CreateDirectory(nginxDst);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create nginx directory: " + ret.msg);
        }

        std::error_code ec;
        for (const auto &entry : fs::directory_iterator(nginxRootSrc, ec)) {
            if (ec) {
                SLOG_WARN << "Failed to iterate nginx source: " << ec.message();
                continue;
            }
            std::string filename = entry.path().filename().string();
            std::string dstPath = utils::JoinPath(nginxDst, filename);

            if (entry.is_directory()) {
                ret = utils::CopyDirectory(entry.path().string(), dstPath);
            } else {
                ec.clear();
                fs::copy_file(entry.path(), dstPath, fs::copy_options::overwrite_existing, ec);
                ret = ec ? MakeError("Failed to copy file: " + entry.path().string() + " -> " + dstPath + ", " +
                                     ec.message())
                         : MakeSuccess();
            }

            if (!ret.IsDefalutSuccess()) {
                RollbackNginxInstall(nginxDst, nginxBackup, hadExistingNginx);
                return MakeError("Failed to copy nginx files: " + ret.msg);
            }
        }

        // 创建系统 nginx 配置软链（server_ → conf.d，snippet_ → snippets）
        auto confRet = InstallScmConfSymlinks(nginxDst);
        if (!confRet.IsDefalutSuccess()) {
            SLOG_ERROR << "Failed to create some nginx conf symlinks, rolling back: " << confRet.msg;
            RollbackNginxInstall(nginxDst, nginxBackup, hadExistingNginx);
            return MakeError("Failed to create nginx conf symlinks");
        }

        // 创建 frontend 软链到 /etc/nginx/conf.d/frontend
        // conf 中使用相对路径 "./frontend"，nginx 以 /etc/nginx/conf.d 为工作目录，
        // 因此需要将 service/nginx/frontend 软链到 /etc/nginx/conf.d/frontend
        auto frontendRet = CreateFrontendSymlink(nginxDst);
        if (!frontendRet.IsDefalutSuccess()) {
            SLOG_WARN << "Failed to create frontend symlink: " << frontendRet.msg;
        }

        // 禁用系统默认站点，避免与 scm 默认站点产生 duplicate default server 冲突
        auto disableRet = DisableSystemDefaultSite();
        if (!disableRet.IsDefalutSuccess()) {
            SLOG_ERROR << "Failed to disable system default site, rolling back: " << disableRet.msg;
            RollbackNginxInstall(nginxDst, nginxBackup, hadExistingNginx);
            return MakeError("Failed to disable system default site: " + disableRet.msg);
        }

        // 清理备份（安装成功）
        if (hadExistingNginx && fs::exists(nginxBackup)) {
            utils::ForceDeleteDirectory(nginxBackup);
        }

        SLOG_INFO << "Nginx initialized at " << nginxDst;
        return MakeSuccess();
    }

    ResultMsg FileManager::ResetNginx() {
        // 先将旧的 <serviceDir>/nginx 迁移到 <serviceDir>/.nginx，保证后续读取路径一致
        EnsureNginxDirMigrated();

        // 1. 卸载系统 nginx conf 软链（使用 scm_ 前缀）
        auto uninstallResult = UninstallFrontend("scm");
        if (!uninstallResult.IsDefalutSuccess()) {
            SLOG_WARN << "Failed to uninstall nginx conf: " << uninstallResult.msg;
        }

        // 2. 移除 waiting.conf 与 frontend 软链（best-effort，失败仅告警）
        RemoveWaitingConfLink();
        RemoveFrontendLink();

        // 3. 恢复系统默认站点
        auto restoreRet = RestoreSystemDefaultSite();
        if (!restoreRet.IsDefalutSuccess()) {
            SLOG_WARN << "Failed to restore system default site: " << restoreRet.msg;
        }

        // 4. 删除 nginx 目录
        std::string nginxDst = GetNginxDir();
        if (fs::exists(nginxDst)) {
            auto delRet = utils::ForceDeleteDirectory(nginxDst);
            if (!delRet.IsDefalutSuccess()) {
                return MakeError("Failed to delete nginx directory: " + delRet.msg);
            }
            SLOG_INFO << "Deleted nginx directory: " << nginxDst;
        } else {
            SLOG_INFO << "No nginx directory found";
        }

        return MakeSuccess();
    }

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg FileManager::SetNginxWaiting() {
        // 先将旧的 <serviceDir>/nginx 迁移到 <serviceDir>/.nginx，保证后续读取路径一致
        EnsureNginxDirMigrated();

        // 1. 检查 nginx 目录中是否存在 waiting.conf
        std::string nginxDst = GetNginxDir();
        std::string waitingSrc = utils::JoinPath(nginxDst, "conf.d", NginxWaitingConfName);

        if (!fs::exists(waitingSrc)) {
            return MakeError("waiting.conf not found in: " + waitingSrc +
                             ", please ensure the nginx package contains conf.d/waiting.conf");
        }

        // 2. 移除现有的 scm_*.conf 软链（conf.d 和 snippets），避免 default_server 冲突
        auto uninstallResult = UninstallFrontend("scm");
        if (!uninstallResult.IsDefalutSuccess()) {
            SLOG_WARN << "Failed to uninstall nginx conf: " << uninstallResult.msg;
        }

        // 3. 保留/重建 frontend 软链
        // 等待状态需要显示 /upSysing 加载页，该页面由前端 SPA 渲染，
        // 因此仍需访问 index.html 与 /assets/ 静态资源，frontend 软链不能移除。
        // 若软链缺失（例如未执行过 init_nginx），此处尝试重建以保证加载页可用。
        std::error_code ec;
        std::string frontendSrc = utils::JoinPath(nginxDst, "frontend");
        if (!fs::exists(NginxFrontendLinkPath, ec) && !fs::is_symlink(NginxFrontendLinkPath, ec)) {
            if (fs::exists(frontendSrc, ec)) {
                std::string frontendTarget = utils::GetAbsolutePath(frontendSrc);
                auto feRet = CreateSymlinkForce(frontendTarget, NginxFrontendLinkPath);
                if (!feRet.IsDefalutSuccess()) {
                    SLOG_WARN << "Failed to create frontend symlink for waiting page: " << feRet.msg;
                }
            } else {
                SLOG_WARN << "frontend directory not found, /upSysing loading page may be unavailable: " << frontendSrc;
            }
        }

        // 4. 移除已有的 scm_waiting.conf（确保幂等）后创建新软链
        auto rmRet = RemoveWaitingConfLink();
        if (!rmRet.IsDefalutSuccess()) {
            return MakeError("Failed to remove existing waiting.conf: " + rmRet.msg);
        }
        fs::create_directories(NginxSystemConfDir, ec);
        std::string targetPath = utils::GetAbsolutePath(waitingSrc);
        auto createRet = CreateSymlinkForce(targetPath, NginxWaitingLinkPath);
        if (!createRet.IsDefalutSuccess()) {
            return MakeError("Failed to create waiting.conf symlink: " + createRet.msg);
        }

        // 5. 禁用系统默认站点（避免 default_server 冲突）
        auto disableRet = DisableSystemDefaultSite();
        if (!disableRet.IsDefalutSuccess()) {
            SLOG_WARN << "Failed to disable system default site: " << disableRet.msg;
        }

        return MakeSuccess();
    }

    ResultMsg FileManager::SetNginxNormal() {
        // 先将旧的 <serviceDir>/nginx 迁移到 <serviceDir>/.nginx，保证后续读取路径一致
        EnsureNginxDirMigrated();

        // 1. 移除 waiting.conf
        auto waitRet = RemoveWaitingConfLink();
        if (!waitRet.IsDefalutSuccess()) {
            return waitRet;
        }

        // 2. 重新创建 scm_*.conf 软链
        std::string nginxDst = GetNginxDir();
        std::string confDir = utils::JoinPath(nginxDst, "conf.d");
        if (!fs::exists(confDir)) {
            return MakeError("Nginx conf.d directory not found: " + confDir + ", please run init_nginx first");
        }
        auto confRet = InstallScmConfSymlinks(nginxDst);
        if (!confRet.IsDefalutSuccess()) {
            SLOG_WARN << "InstallScmConfSymlinks completed with warnings: " << confRet.msg;
        }

        // 3. 创建 frontend 软链（与 InitNginx 一致）
        auto frontendRet = CreateFrontendSymlink(nginxDst);
        if (!frontendRet.IsDefalutSuccess()) {
            SLOG_WARN << "Failed to create frontend symlink: " << frontendRet.msg;
        }

        // 4. 禁用系统默认站点（避免 default_server 冲突）
        auto disableRet = DisableSystemDefaultSite();
        if (!disableRet.IsDefalutSuccess()) {
            SLOG_WARN << "Failed to disable system default site: " << disableRet.msg;
        }

        return MakeSuccess();
    }

    ResultMsg FileManager::DisableSystemDefaultSite() {
        std::error_code ec;
        if (!fs::exists(NginxSystemDefaultSite, ec)) {
            return MakeSuccess();
        }

        auto dirRet = utils::CreateDirectory(mCurDirConfig.backupDir);
        if (!dirRet.IsDefalutSuccess()) {
            return MakeError("Failed to create backup directory: " + dirRet.msg);
        }

        std::string backupPath = utils::JoinPath(mCurDirConfig.backupDir, NginxSitesDefaultBackup);

        // 若已存在历史备份，说明上次 init 已保留过原始站点；本次仅需移除当前系统站点
        ec.clear();
        if (fs::exists(backupPath, ec)) {
            fs::remove(NginxSystemDefaultSite, ec);
            if (ec) {
                return MakeError("Failed to remove system default site: " + ec.message());
            }
            SLOG_INFO << "System default site already backed up, removed current: " << NginxSystemDefaultSite;
            return MakeSuccess();
        }

        // 首次禁用：将系统默认站点移动到备份目录
        ec.clear();
        fs::rename(NginxSystemDefaultSite, backupPath, ec);
        if (ec) {
            // rename 失败时尝试复制后删除
            fs::copy_file(NginxSystemDefaultSite, backupPath, fs::copy_options::overwrite_existing, ec);
            if (ec) {
                return MakeError("Failed to backup system default site: " + ec.message());
            }
            fs::remove(NginxSystemDefaultSite, ec);
            if (ec) {
                return MakeError("Failed to remove system default site after backup: " + ec.message());
            }
        }

        SLOG_INFO << "Disabled system default site: " << NginxSystemDefaultSite << " -> " << backupPath;
        return MakeSuccess();
    }

    ResultMsg FileManager::RestoreSystemDefaultSite() {
        std::string backupPath = utils::JoinPath(mCurDirConfig.backupDir, NginxSitesDefaultBackup);
        std::error_code ec;
        if (!fs::exists(backupPath, ec)) {
            return MakeSuccess();
        }

        fs::create_directories(fs::path(NginxSystemDefaultSite).parent_path(), ec);

        // 若目标已存在，先移除
        ec.clear();
        if (fs::exists(NginxSystemDefaultSite, ec) || fs::is_symlink(NginxSystemDefaultSite, ec)) {
            fs::remove(NginxSystemDefaultSite, ec);
            if (ec) {
                return MakeError("Failed to remove existing system default site: " + ec.message());
            }
        }

        // 恢复备份
        ec.clear();
        fs::rename(backupPath, NginxSystemDefaultSite, ec);
        if (ec) {
            fs::copy_file(backupPath, NginxSystemDefaultSite, fs::copy_options::overwrite_existing, ec);
            if (ec) {
                return MakeError("Failed to restore system default site: " + ec.message());
            }
            fs::remove(backupPath, ec);
        }

        SLOG_INFO << "Restored system default site: " << NginxSystemDefaultSite;
        return MakeSuccess();
    }

    // --- 细粒度升级 ---

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg FileManager::ParseUpgradeDetail(const std::string &detailPath, UpgradeDetail &outDetail) {
        outDetail.replaceDirs.clear();
        outDetail.addDirs.clear();
        outDetail.removeDirs.clear();

        if (detailPath.empty()) {
            return MakeError("up_detail.yaml path is empty");
        }
        if (!fs::exists(detailPath)) {
            return MakeError("up_detail.yaml not found: " + detailPath);
        }

        try {
            YAML::Node root = YAML::LoadFile(detailPath);
            if (root["replace"]) {
                for (const auto &item : root["replace"]) {
                    std::string name = item.as<std::string>("");
                    if (!name.empty()) {
                        outDetail.replaceDirs.push_back(name);
                    }
                }
            }
            if (root["add"]) {
                for (const auto &item : root["add"]) {
                    std::string name = item.as<std::string>("");
                    if (!name.empty()) {
                        outDetail.addDirs.push_back(name);
                    }
                }
            }
            if (root["remove"]) {
                for (const auto &item : root["remove"]) {
                    std::string name = item.as<std::string>("");
                    if (!name.empty()) {
                        outDetail.removeDirs.push_back(name);
                    }
                }
            }
        } catch (const YAML::Exception &e) {
            return MakeError("Failed to parse up_detail.yaml: " + std::string(e.what()));
        }

        SLOG_INFO << "Parsed upgrade detail: replace=" << outDetail.replaceDirs.size()
                  << " add=" << outDetail.addDirs.size() << " remove=" << outDetail.removeDirs.size();
        return MakeSuccess();
    }

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg FileManager::BackupForFineGrainedUpgrade(const std::string &serviceName, const UpgradeDetail &detail) {
        std::string serviceDir = GetServiceDir(serviceName);
        std::string backupRoot = GetBackupDir(serviceName);
        std::string filesBackup = utils::JoinPath(backupRoot, "files_backup");

        // 确保备份根目录存在
        auto ret = utils::CreateDirectory(backupRoot);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create backup root: " + ret.msg);
        }
        // 若已有 files_backup 先清理
        if (fs::exists(filesBackup)) {
            utils::ForceDeleteDirectory(filesBackup);
        }
        ret = utils::CreateDirectory(filesBackup);
        if (!ret.IsDefalutSuccess()) {
            return MakeError("Failed to create files_backup: " + ret.msg);
        }

        // 强制备份 service.yaml：ApplyFineGrainedUpgrade 会无条件覆盖它，回滚时必须能恢复
        // 不依赖 up_detail.yaml 的 replace 列表是否包含 service.yaml
        {
            std::string yamlSrc = utils::JoinPath(serviceDir, DefaultServiceName);
            if (fs::exists(yamlSrc)) {
                std::string yamlDst = utils::JoinPath(filesBackup, DefaultServiceName);
                auto yamlRet = CopyEntry(yamlSrc, yamlDst);
                if (!yamlRet.IsDefalutSuccess()) {
                    return MakeError("Failed to backup service.yaml: " + yamlRet.msg);
                }
            }
        }

        // 备份 replace 和 remove 列表中服务目录下存在的文件/目录
        // 使用 CopyEntry 统一处理：目录走 CopyDirectory，文件走 copy_file
        auto backupEntry = [&serviceDir, &filesBackup](const std::string &name) -> ResultMsg {
            std::string src = utils::JoinPath(serviceDir, name);
            if (!fs::exists(src)) {
                return MakeSuccess();
            }
            std::string dst = utils::JoinPath(filesBackup, name);
            return CopyEntry(src, dst);
        };

        for (const auto &dir : detail.replaceDirs) {
            auto r = backupEntry(dir);
            if (!r.IsDefalutSuccess()) {
                return MakeError("Failed to backup replace entry " + dir + ": " + r.msg);
            }
        }
        for (const auto &dir : detail.removeDirs) {
            auto r = backupEntry(dir);
            if (!r.IsDefalutSuccess()) {
                return MakeError("Failed to backup remove entry " + dir + ": " + r.msg);
            }
        }

        // 若 frontend 在 replace 列表中且服务依赖 nginx，备份 nginx.conf
        bool frontendInReplace = false;
        for (const auto &dir : detail.replaceDirs) {
            if (dir == "frontend" || dir == "nginx") {
                frontendInReplace = true;
                break;
            }
        }
        if (frontendInReplace && fs::exists(GetFrontendDir(serviceName))) {
            std::string frontendDir = GetFrontendDir(serviceName);
            std::string nginxBackup = utils::JoinPath(backupRoot, "nginx_backup");
            // 备份整个 nginx 目录（含 conf.d 和 frontend）
            auto backupRet = utils::CopyDirectory(frontendDir, nginxBackup);
            if (!backupRet.IsDefalutSuccess()) {
                SLOG_WARN << "Failed to backup nginx directory: " << backupRet.msg;
            }
        }

        SLOG_INFO << "Fine-grained backup completed for service: " << serviceName;
        return MakeSuccess();
    }

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg FileManager::ApplyFineGrainedUpgrade(const std::string &serviceName, const std::string &sourceDir,
                                                   const UpgradeDetail &detail) {
        std::string serviceDir = GetServiceDir(serviceName);

        // 0. 强制覆盖 service.yaml：服务元信息文件必须随升级整体替换，不受 up_detail.yaml 管辖
        //    后续 ConfigLoader::UpgradeService 会重新解析新 service.yaml，解析失败则触发回退
        std::string srcYaml = utils::JoinPath(sourceDir, DefaultServiceName);
        std::string dstYaml = utils::JoinPath(serviceDir, DefaultServiceName);
        if (fs::exists(srcYaml)) {
            auto yamlRet = CopyEntry(srcYaml, dstYaml);
            if (!yamlRet.IsDefalutSuccess()) {
                return MakeError("Failed to replace service.yaml: " + yamlRet.msg);
            }
            SLOG_INFO << "Replaced service.yaml for service: " << serviceName;
        } else {
            SLOG_WARN << "New service.yaml not found in source dir, skip replace: " << srcYaml;
        }

        // 1. replace: 删除服务目录下同名文件/目录后从源拷贝
        // ForceDeleteDirectory 内部使用 remove_all，对文件和目录均适用
        for (const auto &dir : detail.replaceDirs) {
            std::string srcDir = utils::JoinPath(sourceDir, dir);
            std::string dstDir = utils::JoinPath(serviceDir, dir);
            if (!fs::exists(srcDir)) {
                SLOG_WARN << "Replace source not exists, skip: " << srcDir;
                continue;
            }
            if (fs::exists(dstDir)) {
                auto ret = utils::ForceDeleteDirectory(dstDir);
                if (!ret.IsDefalutSuccess()) {
                    return MakeError("Failed to delete existing entry " + dir + ": " + ret.msg);
                }
            }
            auto ret = CopyEntry(srcDir, dstDir);
            if (!ret.IsDefalutSuccess()) {
                return MakeError("Failed to copy replace entry " + dir + ": " + ret.msg);
            }
            SLOG_INFO << "Replaced entry: " << dir;
        }

        // 2. remove: 仅删除服务目录下对应文件/目录
        for (const auto &dir : detail.removeDirs) {
            std::string dstDir = utils::JoinPath(serviceDir, dir);
            if (fs::exists(dstDir)) {
                auto ret = utils::ForceDeleteDirectory(dstDir);
                if (!ret.IsDefalutSuccess()) {
                    return MakeError("Failed to remove entry " + dir + ": " + ret.msg);
                }
                SLOG_INFO << "Removed entry: " << dir;
            }
        }

        // 3. add: 从源拷贝对应文件/目录到服务目录
        for (const auto &dir : detail.addDirs) {
            std::string srcDir = utils::JoinPath(sourceDir, dir);
            std::string dstDir = utils::JoinPath(serviceDir, dir);
            if (!fs::exists(srcDir)) {
                SLOG_WARN << "Add source not exists, skip: " << srcDir;
                continue;
            }
            if (fs::exists(dstDir)) {
                return MakeError("Add target already exists: " + dir);
            }
            auto ret = CopyEntry(srcDir, dstDir);
            if (!ret.IsDefalutSuccess()) {
                return MakeError("Failed to copy add entry " + dir + ": " + ret.msg);
            }
            SLOG_INFO << "Added entry: " << dir;
        }

        SLOG_INFO << "Fine-grained upgrade applied for service: " << serviceName;
        return MakeSuccess();
    }

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg FileManager::RollbackFineGrainedUpgrade(const std::string &serviceName) {
        std::string serviceDir = GetServiceDir(serviceName);
        std::string backupRoot = GetBackupDir(serviceName);
        std::string filesBackup = utils::JoinPath(backupRoot, "files_backup");

        if (!fs::exists(filesBackup)) {
            return MakeError("files_backup not found for service: " + serviceName);
        }

        // 遍历 files_backup 下每个条目（文件或目录），覆盖恢复到服务目录
        // 使用 CopyEntry 统一处理，保证 service.yaml 等文件也能正确回滚
        std::error_code ec;
        for (const auto &entry : fs::directory_iterator(filesBackup, ec)) {
            std::string name = entry.path().filename().string();
            std::string dst = utils::JoinPath(serviceDir, name);
            if (fs::exists(dst)) {
                auto ret = utils::ForceDeleteDirectory(dst);
                if (!ret.IsDefalutSuccess()) {
                    SLOG_WARN << "Failed to delete entry during rollback: " << name;
                }
            }
            auto ret = CopyEntry(entry.path().string(), dst);
            if (!ret.IsDefalutSuccess()) {
                return MakeError("Failed to restore entry " + name + ": " + ret.msg);
            }
            SLOG_INFO << "Restored entry: " << name;
        }

        // 恢复 nginx 目录（若存在 nginx_backup）
        std::string nginxBackup = utils::JoinPath(backupRoot, "nginx_backup");
        if (fs::exists(nginxBackup)) {
            std::string frontendDir = GetFrontendDir(serviceName);
            // 清除当前 nginx 目录并从备份恢复
            if (fs::exists(frontendDir)) {
                utils::ForceDeleteDirectory(frontendDir);
            }
            auto restoreRet = utils::CopyDirectory(nginxBackup, frontendDir);
            if (!restoreRet.IsDefalutSuccess()) {
                SLOG_WARN << "Failed to restore nginx directory: " << restoreRet.msg;
            }
        }

        SLOG_INFO << "Fine-grained rollback completed for service: " << serviceName;
        return MakeSuccess();
    }

    // --- 解压目录直接安装 ---

    ResultMsg FileManager::InstallSoftwarePackageFromDir(const std::string &serviceName,
                                                         const std::string &softwareDir) {
        // InstallSoftwarePackage 已支持 softwareDir/<serviceName> 形式，直接复用
        return InstallSoftwarePackage(serviceName, softwareDir);
    }

    void FileManager::CleanupService(const std::string &serviceName) {
        // 删除服务目录
        RemoveSoftwarePackage(serviceName);

        // 删除systemd服务文件
        DeleteServiceFile(serviceName);

        // 删除软链接
        DeleteServiceSymlink(serviceName);
    }

}  // namespace qifeng::scm
