/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "common/types.h"
#include "scmctl/scmctl_client.h"

#include "ipc/protocol.h"
#include "ipc/uds.h"

#include <array>
#include <cstdio>       // popen / pclose
#include <string>
#include <sys/wait.h>   // WEXITSTATUS
#include <vector>

namespace qifeng::scm {

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ScmResponse ScmCtlClient::SendRequest(const ScmRequest &request, const std::string &socketPath) {
        ScmResponse response;
        response.code = -1;
        response.message = "Unknown error";

        // 创建UDS客户端
        UdsWrapper udsClient(UdsMode::CLIENT, socketPath);
        ResultMsg ret = udsClient.Initialize();
        if (ret.code != 0) {
            response.message = ret.msg;
            return response;
        }

        // 连接到scmd服务端
        ret = udsClient.Connect();
        if (ret.code != 0) {
            response.message = ret.msg;
            return response;
        }

        // 编码并发送请求
        std::string encoded = ControlProtocol::EncodeRequest(request);
        ssize_t sent = udsClient.Send(udsClient.GetSocketFd(), encoded);
        if (sent < 0) {
            response.message = "Failed to send request to scmd";
            return response;
        }

        // 接收响应数据
        std::string buffer;
        constexpr size_t bufSize = 4096;
        std::vector<char> recvBuf(bufSize);

        while (true) {
            ssize_t bytesRead = udsClient.Receive(udsClient.GetSocketFd(), recvBuf.data(), bufSize);
            if (bytesRead < 0) {
                response.message = "Failed to receive response from scmd";
                return response;
            }
            if (bytesRead == 0) {
                // 服务端关闭连接
                break;
            }
            buffer.append(recvBuf.data(), static_cast<size_t>(bytesRead));

            // 尝试从缓冲区提取完整消息
            auto messages = ControlProtocol::ExtractMessages(buffer);
            if (!messages.empty()) {
                // 取第一条完整消息作为响应
                if (!ControlProtocol::DecodeResponse(messages[0], response)) {
                    response.code = -1;
                    response.message = "Failed to decode response from scmd";
                    return response;
                }
                break;
            }
        }
        return response;
    }

    // shell 命令执行结果：launched 表示 popen 是否成功，exitCode 为子进程退出码
    struct ShellExecResult {
        bool launched;       // popen 是否成功启动子进程
        int exitCode;        // 子进程退出码（launched=false 时无意义）
        std::string output;  // 合并后的 stdout+stderr
    };

    // 执行 shell 命令并捕获合并后的 stdout+stderr 与退出码
    static ShellExecResult RunShellCapture(const std::string &cmd) {
        // NOLINTNEXTLINE(cert-env33-c) 命令字符串由调用方构造，此处仅负责执行
        FILE* pipe = popen(cmd.c_str(), "r");
        if (pipe == nullptr) {
            return {false, -1, ""};
        }

        // 读取子进程的全部输出
        std::string output;
        std::array<char, 256> buf{};
        while (fgets(buf.data(), buf.size(), pipe) != nullptr) {
            output += buf.data();
        }
        int status = pclose(pipe);
        int exitCode = WIFEXITED(status) ? WEXITSTATUS(status) : -1;

        // 去除输出末尾的换行，便于日志清晰
        while (!output.empty() && (output.back() == '\n' || output.back() == '\r')) {
            output.pop_back();
        }
        return {true, exitCode, output};
    }

    ScmResponse ScmCtlClient::ControlScmdSelf(ScmCommand cmd) const {
        // 将 ScmCommand 映射为 systemctl 动作名称（仅 START/STOP/RESTART 支持自控）
        // 不使用 switch：项目开启 -Wswitch-enum，未覆盖全部枚举值会报错
        std::string action;
        if (cmd == ScmCommand::START) {
            action = "start";
        } else if (cmd == ScmCommand::STOP) {
            action = "stop";
        } else if (cmd == ScmCommand::RESTART) {
            action = "restart";
        } else {
            // 其它命令不支持自控，直接拒绝
            ScmResponse bad;
            bad.code = -1;
            bad.message = "Unsupported command for scmd self control";
            return bad;
        }

        // 直接在客户端调用 systemctl 控制守护进程，合并 stdout+stderr 以捕获 polkit/认证错误
        const std::string shellCmd = "systemctl " + action + " qifeng_scmd.service 2>&1";
        ShellExecResult result = RunShellCapture(shellCmd);

        ScmResponse resp;
        if (!result.launched) {
            // popen 失败属极端情况（系统资源不足等），单独给出明确提示
            resp.code = -1;
            resp.message = action + " failed: popen failed to run systemctl";
        } else if (result.exitCode == 0) {
            resp.code = 0;
            // 输出非空时附带 systemctl 的提示信息，否则给出简洁成功消息
            resp.message = result.output.empty()
                               ? (action + " succeeded")
                               : (action + " succeeded: " + result.output);
        } else {
            resp.code = -1;
            // 失败时输出携带 systemctl 的错误（含非 root 用户的认证错误）
            resp.message = action + " failed: " + (result.output.empty() ? "unknown error" : result.output);
        }
        return resp;
    }

    // 将 Json::Value 转为字符串，支持字符串/整数/无符号/浮点/bool
    static std::string JsonValueToString(const Json::Value &value) {
        if (value.isString()) {
            return value.asString();
        }
        if (value.isInt64()) {
            return std::to_string(value.asInt64());
        }
        if (value.isUInt64()) {
            return std::to_string(value.asUInt64());
        }
        if (value.isInt() || value.isUInt()) {
            return std::to_string(value.asInt());
        }
        if (value.isDouble()) {
            return std::to_string(value.asDouble());
        }
        if (value.isBool()) {
            return value.asBool() ? "true" : "false";
        }
        if (value.isNull()) {
            return "";
        }
        return value.toStyledString();
    }

    // 对 Json::Object 格式化为简洁键值对，跳过空值
    static std::string FormatJsonObject(const Json::Value &obj) {
        std::string output;
        for (const auto &key : obj.getMemberNames()) {
            const auto &value = obj[key];
            std::string strValue = JsonValueToString(value);
            if (strValue.empty()) {
                continue;  // 跳过空值
            }
            output += key + ": " + strValue + "\n";
        }
        return output;
    }

    // 对 Json::Array 格式化为简洁表格（适用于 list 命令）
    static std::string FormatJsonArray(const Json::Value &arr) {
        if (arr.empty()) {
            return "";
        }

        std::ostringstream oss;
        // 表头
        oss << std::left << std::setw(16) << "NAME" << std::setw(11) << "VERSION" << std::setw(12) << "AUTO_START"
            << "ACTIVE" << "\n";
        oss << std::string(54, '-') << "\n";
        for (const auto &item : arr) {
            std::string name = item.isMember("serviceName") ? item["serviceName"].asString() : "";
            std::string version = item.isMember("version") ? item["version"].asString() : "";
            std::string autoStart = (item.isMember("isAutoStart") && item["isAutoStart"].asBool()) ? "true" : "false";
            std::string active = (item.isMember("active") && item["active"].asBool()) ? "true" : "false";

            oss << std::left << std::setw(16) << name << std::setw(11) << version << std::setw(12) << autoStart
                << active << "\n";
        }
        return oss.str();
    }

    // 根据 data 类型统一格式化
    static std::string FormatResponseData(const Json::Value &data) {
        if (data.isObject()) {
            return FormatJsonObject(data);
        }
        if (data.isArray()) {
            return FormatJsonArray(data);
        }
        return data.toStyledString() + "\n";
    }

    ResultMsg ScmCtlClient::FormatOutput(const ScmResponse &response) {
        std::string output;
        if (response.code == 0) {
            output = "[OK] " + response.message + "\n";
            if (!response.data.isNull()) {
                output += FormatResponseData(response.data);
            }
        } else if (response.code == 1) {
            output = "[WARN] " + response.message + "\n";
            if (!response.data.isNull()) {
                output += FormatResponseData(response.data);
            }
        } else {
            output = "[FAIL] " + response.message + "\n";
        }
        return ResultMsg(response.code, output);
    }

}  // namespace qifeng::scm
