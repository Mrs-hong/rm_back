/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */
#include "common/version.hpp"
#include "scmctl/cli_commands.h"
#include "scmctl/cli_parser.h"

#include <CLI/CLI.hpp>
#include <memory>
#include <vector>

namespace qifeng::scm {

    // 此处 LocalCliCommand 为完整类型，unique_ptr 成员可正常析构
    CliParser::CliParser() = default;
    CliParser::~CliParser() = default;

    // NOLINTNEXTLINE(readability-function-size,readability-function-cognitive-complexity)
    ResultMsg CliParser::Parse(int argc, char** argv) {
        CLI::App app {"qf_scmc - Service Control Manager Client"};
        app.set_version_flag("--version,-v", qifeng::scm::GetVersionInfo().version);
        app.require_subcommand(0, 1);

        // 注册所有远程命令（走UDS）
        std::vector<std::unique_ptr<CliCommand>> commands;
        commands.emplace_back(std::make_unique<InstallCommand>());
        commands.emplace_back(std::make_unique<StartCommand>());
        commands.emplace_back(std::make_unique<StopCommand>());
        commands.emplace_back(std::make_unique<RestartCommand>());
        commands.emplace_back(std::make_unique<ReloadCommand>());
        commands.emplace_back(std::make_unique<UpgradeCommand>());
        commands.emplace_back(std::make_unique<UpgradesCommand>());
        commands.emplace_back(std::make_unique<ListCommand>());
        commands.emplace_back(std::make_unique<InfoCommand>());
        commands.emplace_back(std::make_unique<LogCommand>());
        commands.emplace_back(std::make_unique<UninstallCommand>());
        commands.emplace_back(std::make_unique<KillCommand>());
        commands.emplace_back(std::make_unique<SlogCommand>());
        commands.emplace_back(std::make_unique<CheckCommand>());
        commands.emplace_back(std::make_unique<InitNginxCommand>());
        commands.emplace_back(std::make_unique<ResetNginxCommand>());
        commands.emplace_back(std::make_unique<AddModelCommand>());
        commands.emplace_back(std::make_unique<ClearModelCommand>());

        // 注册所有本地命令（不走UDS，由qf_scmc直接执行）
        mLocalCommands.emplace_back(std::make_unique<CalSnCommand>());
        mLocalCommands.emplace_back(std::make_unique<VerifySnCommand>());

        for (auto &cmd : commands) {
            cmd->Setup(app);
        }
        for (auto &cmd : mLocalCommands) {
            cmd->Setup(app);
        }

        try {
            app.parse(argc, argv);
        } catch (const CLI::CallForVersion &e) {
            mRequest.data = VersionRequest{};
            return MakeWarning(e.what());
        } catch (const CLI::ParseError &e) {
            if (e.get_exit_code() == 0) {
                return MakeWarning(app.help());
            }
            return MakeError(std::string("Error: ") + e.what() + "\n" + app.help());
        }

        // 遍历远程命令，命中者组装 Request
        for (auto &cmd : commands) {
            ResultMsg result = cmd->BuildRequest(app, mRequest);
            if (result.code == 0) {
                return MakeSuccess();
            }
            if (result.code == -1) {
                return result;
            }
            // code == 2 表示未命中，继续尝试下一个命令
        }

        // 遍历本地命令，命中者记录并返回
        for (auto &cmd : mLocalCommands) {
            ResultMsg result = cmd->Build(app);
            if (result.code == 0) {
                mHasLocal = true;
                mMatchedLocal = cmd.get();
                return MakeSuccess();
            }
            if (result.code == -1) {
                return result;
            }
            // code == 2 表示未命中，继续尝试下一个命令
        }

        // 没有子命令
        return MakeWarning(app.help());
    }

    const ScmRequest &CliParser::GetRequest() const {
        return mRequest;
    }

    bool CliParser::HasLocalCommand() const {
        return mHasLocal;
    }

    ScmResponse CliParser::ExecuteLocal() {
        if (mMatchedLocal == nullptr) {
            ScmResponse resp;
            resp.code = -1;
            resp.message = "no local command matched";
            return resp;
        }
        return mMatchedLocal->Execute();
    }

}  // namespace qifeng::scm
