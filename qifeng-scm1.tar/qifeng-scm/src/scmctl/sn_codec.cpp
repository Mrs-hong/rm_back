/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "scmctl/sn_codec.h"

#include "common/cmd_execute.h"
#include "common/types.h"

#include <algorithm>
#include <array>
#include <cctype>
#include <cstdio>
#include <string>

namespace qifeng::scm {

    namespace {
        // SN格式常量定义（PascalCase，与 scmd_def.h 风格一致）
        constexpr size_t SnTotalLength = 16;    // SN总长度
        constexpr size_t SnPrefixLength = 14;  // SN前缀长度（不含校验码）
        constexpr size_t SnCheckCodeLength = 2; // 校验码长度

        /**
         * @brief 判断字符串是否全部为数字字符
         */
        bool IsAllDigits(const std::string &s) {
            if (s.empty()) {
                return false;
            }
            return std::all_of(s.begin(), s.end(), [](unsigned char c) { return std::isdigit(c); });
        }

        /**
         * @brief 判断字符串是否全部为大写字母
         */
        bool IsAllUpperAlpha(const std::string &s) {
            if (s.empty()) {
                return false;
            }
            return std::all_of(s.begin(), s.end(),
                               [](unsigned char c) { return std::isupper(c) && std::isalpha(c); });
        }
    }  // namespace

    ResultMsg SnCodec::GenCheckCode(const std::string &prefix, std::string &checkCode) {
        // prefix 由调用方保证仅含 [A-Z0-9]，可安全用于 shell 单引号
        std::string shellCmd = "printf '%s' '" + prefix + "' | sha256sum";
        CmdOptions opts;
        opts.timeout_ms = 3000;
        opts.max_output = 1 << 16;
        CmdResult result = RunCmd("sh", {"-c", shellCmd}, opts);
        if (result.timed_out) {
            return MakeError("sha256sum timed out");
        }
        if (result.exit_code != 0) {
            return MakeError("sha256sum failed: " + result.output);
        }
        // 输出形如 "<64位hex>  -"，取前64位hex
        if (result.output.size() < 64) {
            return MakeError("invalid sha256sum output: " + result.output);
        }
        std::string hex = result.output.substr(0, 64);

        // 前8位hex转uint32，mod 100 后格式化为2位十进制
        uint32_t val = 0;
        try {
            val = static_cast<uint32_t>(std::stoul(hex.substr(0, 8), nullptr, 16));
        } catch (...) {
            return MakeError("parse sha256 hex failed: " + hex.substr(0, 8));
        }
        std::array<char, 4> buf {};
        // NOLINTNEXTLINE(cppcoreguidelines-pro-type-vararg)
        std::snprintf(buf.data(), buf.size(), "%02u", val % 100);
        checkCode = buf.data();
        return MakeSuccess();
    }

    ResultMsg SnCodec::ValidatePrefix(const std::string &prefix) {
        // 1. 长度校验
        if (prefix.size() != SnPrefixLength) {
            return MakeError("prefix length must be " + std::to_string(SnPrefixLength) +
                             " (got " + std::to_string(prefix.size()) + ")");
        }

        // 2. 分段格式校验
        std::string model = prefix.substr(0, 2);    // 型号: 大写字母
        std::string year = prefix.substr(2, 2);     // 年份: 数字
        std::string month = prefix.substr(4, 2);    // 月份: 数字 01-12
        std::string factory = prefix.substr(6, 2);  // 工厂码: 数字
        std::string serial = prefix.substr(8, 6);   // 流水号: 数字

        if (!IsAllUpperAlpha(model)) {
            return MakeError("invalid model part: " + model);
        }
        if (!IsAllDigits(year)) {
            return MakeError("invalid year part: " + year);
        }
        if (!IsAllDigits(month)) {
            return MakeError("invalid month part: " + month);
        }
        int mon = std::stoi(month);
        if (mon < 1 || mon > 12) {
            return MakeError("month out of range: " + month);
        }
        if (!IsAllDigits(factory)) {
            return MakeError("invalid factory part: " + factory);
        }
        if (!IsAllDigits(serial)) {
            return MakeError("invalid serial part: " + serial);
        }
        return MakeSuccess();
    }

    ResultMsg SnCodec::ValidateFormat(const std::string &sn) {
        // 1. 长度校验
        if (sn.size() != SnTotalLength) {
            return MakeError("SN length must be " + std::to_string(SnTotalLength) +
                             " (got " + std::to_string(sn.size()) + ")");
        }

        // 2. 前14位复用 ValidatePrefix 校验
        ResultMsg r = ValidatePrefix(sn.substr(0, SnPrefixLength));
        if (!r.IsDefalutSuccess()) {
            return r;
        }

        // 3. 校验码2位为数字
        std::string check = sn.substr(SnPrefixLength, SnCheckCodeLength);
        if (!IsAllDigits(check)) {
            return MakeError("invalid check code part: " + check);
        }
        return MakeSuccess();
    }

    ScmResponse SnCodec::Calculate(const std::string &prefix) {
        ScmResponse resp;
        resp.code = -1;

        // 1. 校验前14位格式
        ResultMsg r = ValidatePrefix(prefix);
        if (!r.IsDefalutSuccess()) {
            resp.message = "invalid prefix: " + r.msg;
            return resp;
        }

        // 2. 生成2位校验码
        std::string checkCode;
        r = GenCheckCode(prefix, checkCode);
        if (!r.IsDefalutSuccess()) {
            resp.message = "generate check code failed: " + r.msg;
            return resp;
        }

        // 3. 拼接完整16位SN（FormatOutput 会添加 "[OK] " 前缀）
        resp.code = 0;
        resp.message = prefix + checkCode;
        return resp;
    }

    ScmResponse SnCodec::Verify(const std::string &sn) {
        ScmResponse resp;
        resp.code = -1;

        // 1. 格式校验
        ResultMsg r = ValidateFormat(sn);
        if (!r.IsDefalutSuccess()) {
            resp.message = "SN invalid: " + r.msg;
            return resp;
        }

        // 2. 校验码比对
        std::string expected;
        r = GenCheckCode(sn.substr(0, SnPrefixLength), expected);
        if (!r.IsDefalutSuccess()) {
            resp.message = "SN invalid: compute check code failed: " + r.msg;
            return resp;
        }
        std::string actual = sn.substr(SnPrefixLength, SnCheckCodeLength);
        if (actual != expected) {
            resp.message =
                "SN invalid: check code mismatch: expected " + expected + ", got " + actual;
            return resp;
        }

        // 3. 合法
        resp.code = 0;
        resp.message = "SN valid: " + sn;
        return resp;
    }

}  // namespace qifeng::scm
