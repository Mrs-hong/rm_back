/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "scmctl/cli_parser.h"
#include "scmctl/scmctl_client.h"

#include "common/scmd_def.h"
#include "ipc/data_def.h"

#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <string>
#include <yaml-cpp/yaml.h>

namespace {
    /**
     * @brief 获取scmd的UDS socket路径
     * @details 优先读取scmd.yaml中的uds.socket_path，其次环境变量SCMD_SOCK，最后使用默认路径
     * @return socket路径
     */
    // NOLINTNEXTLINE(readability-function-size)
    std::string GetSocketPath() {
        // 1. 优先从scmd.yaml读取uds.socket_path，与scmd保持一致
        try {
            if (std::filesystem::exists(qifeng::scm::DefaultConfigPath)) {
                YAML::Node config = YAML::LoadFile(qifeng::scm::DefaultConfigPath);
                if (config["scmd"] && config["scmd"]["uds"] && config["scmd"]["uds"]["socket_path"]) {
                    std::string socketPath = config["scmd"]["uds"]["socket_path"].as<std::string>();
                    if (!socketPath.empty()) {
                        return socketPath;
                    }
                }
            }
        } catch (...) {
            // yaml解析失败，继续回退到环境变量和默认路径
        }

        // 2. 环境变量SCMD_SOCK
        const char* envSock = std::getenv("SCMD_SOCK");
        if (envSock != nullptr && envSock[0] != '\0') {
            return std::string(envSock);
        }

        // 3. 默认路径
        return "/run/qifeng_scm/scmd.sock";
    }
}  // namespace

// NOLINTNEXTLINE(readability-function-size,readability-function-cognitive-complexity)
int main(int argc, char* argv[]) {
    // 1. 解析命令行参数
    qifeng::scm::CliParser parser;
    qifeng::scm::ResultMsg result = parser.Parse(argc, argv);
    if (!result.IsDefalutSuccess()) {
        if (result.code == 1) {
            std::cout << result.msg;
            return 0;
        }
        std::cerr << result.msg;
        return 1;
    }

    // 2. 本地命令直接执行，不走UDS，输出复用 FormatOutput 与现有命令统一
    qifeng::scm::ScmCtlClient client;
    if (parser.HasLocalCommand()) {
        qifeng::scm::ScmResponse response = parser.ExecuteLocal();
        qifeng::scm::ResultMsg fmtResult = client.FormatOutput(response);
        if (fmtResult.code == -1) {
            std::cerr << fmtResult.msg;
        } else {
            std::cout << fmtResult.msg;
        }
        return fmtResult.code;
    }

    // 3. start/stop/restart 未指定 -n 时，由客户端直接通过 systemctl 控制 scmd 自身
    //    不走 UDS，避免守护进程未运行（start 自控失败）或守护进程自我停止被中断（stop 自控失败）的死锁
    {
        const qifeng::scm::ScmRequest& req = parser.GetRequest();
        const qifeng::scm::ScmCommand cmd = req.Command();
        if (cmd == qifeng::scm::ScmCommand::START ||
            cmd == qifeng::scm::ScmCommand::STOP ||
            cmd == qifeng::scm::ScmCommand::RESTART) {
            // 从对应请求结构体中提取 serviceName，为空即表示操作 scmd 自身
            // 各分支使用不同变量名，避免 -Wshadow 误报
            std::string serviceName;
            if (const auto* startReq = std::get_if<qifeng::scm::StartRequest>(&req.data); startReq != nullptr) {
                serviceName = startReq->serviceName;
            } else if (const auto* stopReq = std::get_if<qifeng::scm::StopRequest>(&req.data); stopReq != nullptr) {
                serviceName = stopReq->serviceName;
            } else if (const auto* restartReq = std::get_if<qifeng::scm::RestartRequest>(&req.data); restartReq != nullptr) {
                serviceName = restartReq->serviceName;
            }

            if (serviceName.empty()) {
                // 自控直接调用 systemctl，输出复用 FormatOutput 与现有命令统一
                qifeng::scm::ScmResponse resp = client.ControlScmdSelf(cmd);
                qifeng::scm::ResultMsg fmtResult = client.FormatOutput(resp);
                if (fmtResult.code == -1) {
                    std::cerr << fmtResult.msg;
                } else {
                    std::cout << fmtResult.msg;
                }
                return fmtResult.code;
            }
        }
    }

    // 4. 获取socket路径
    std::string socketPath = GetSocketPath();

    // 5. 发送请求并获取响应
    qifeng::scm::ScmResponse response = client.SendRequest(parser.GetRequest(), socketPath);

    // 6. 输出响应
    // SLOG 命令的日志原文直接打印，不做多余格式化（不加 [OK] 前缀、不格式化 data）
    if (parser.GetRequest().Command() == qifeng::scm::ScmCommand::SLOG) {
        if (response.code == 0) {
            std::cout << response.message;
            return 0;
        }
        std::cerr << response.message << "\n";
        return response.code == 0 ? 0 : 1;
    }

    // 其它命令走统一格式化输出
    qifeng::scm::ResultMsg fmtResult = client.FormatOutput(response);
    if (fmtResult.code == -1) {
        std::cerr << fmtResult.msg;
    } else {
        std::cout << fmtResult.msg;
    }
    return fmtResult.code;
}
