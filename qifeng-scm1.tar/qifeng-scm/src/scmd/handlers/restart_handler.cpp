/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "scmd/handlers/restart_handler.h"

#include "common/types.h"
#include "ipc/data_def.h"
#include "qifeng_framework/common/logger.h"
#include "scmd/handler_registry.h"
#include "service_manager/key_recoder.h"
#include "service_manager/service_manager.h"

namespace qifeng::scm {

    ScmCommand RestartHandler::GetCommand() const {
        return ScmCommand::RESTART;
    }

    ScmResponse RestartHandler::Handle(const ScmRequest& request,
                                       const ServiceContext& ctx,
                                       KeyOperationRecorder& /*recorder*/) {
        const auto* params = std::get_if<RestartRequest>(&request.data);
        if (params == nullptr || params->serviceName.empty()) {
            // scmd 自控已由客户端直接通过 systemctl 处理，此处为防御性校验
            SLOG_WARN << "Restart command reached handler without service name";
            ScmResponse response;
            response.code = -1;
            response.message =
                "service name is required (control of scmd self is handled client-side via systemctl)";
            return response;
        }

        ScmResponse response;
        auto result = ctx.serviceManager->RestartService(params->serviceName);
        response.code = result.code;
        response.message = result.msg;
        return response;
    }

    REGISTER_COMMAND_HANDLER(ScmCommand::RESTART, RestartHandler)

}  // namespace qifeng::scm
