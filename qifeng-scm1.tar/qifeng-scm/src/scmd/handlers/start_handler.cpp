/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "scmd/handlers/start_handler.h"

#include "common/types.h"
#include "ipc/data_def.h"
#include "qifeng_framework/common/logger.h"
#include "scmd/handler_registry.h"
#include "service_manager/key_recoder.h"
#include "service_manager/service_manager.h"

namespace qifeng::scm {

    ScmCommand StartHandler::GetCommand() const {
        return ScmCommand::START;
    }

    ScmResponse StartHandler::Handle(const ScmRequest& request,
                                     const ServiceContext& ctx,
                                     KeyOperationRecorder& recorder) {
        const auto* params = std::get_if<StartRequest>(&request.data);
        if (params == nullptr || params->serviceName.empty()) {
            // scmd 自控已由客户端直接通过 systemctl 处理，此处为防御性校验
            SLOG_WARN << "Start command reached handler without service name";
            ScmResponse response;
            response.code = -1;
            response.message =
                "service name is required (control of scmd self is handled client-side via systemctl)";
            return response;
        }

        ScmResponse response;
        recorder.RecordOperation({"start", params->serviceName, 2, "", ""});
        auto result = ctx.serviceManager->StartService(params->serviceName);
        response.code = result.code;
        response.message = result.msg;
        recorder.UpdateResult(result.IsDefalutSuccess() ? 0 : 1);
        if (result.IsDefalutSuccess()) {
            recorder.Clear();
        }
        return response;
    }

    ResultMsg StartHandler::Recover(const KeyOperationRecord& record, const ServiceContext& ctx) {
        SLOG_INFO << "Start was interrupted, retrying: " << record.serviceName;
        return ctx.serviceManager->StartService(record.serviceName);
    }

    REGISTER_COMMAND_HANDLER(ScmCommand::START, StartHandler)

}  // namespace qifeng::scm
