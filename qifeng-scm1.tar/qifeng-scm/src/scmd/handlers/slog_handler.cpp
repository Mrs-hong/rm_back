/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "scmd/handlers/slog_handler.h"

#include "common/types.h"
#include "ipc/data_def.h"
#include "qifeng_framework/common/logger.h"
#include "scmd/handler_registry.h"
#include "scmd/service_operations.h"
#include "service_manager/key_recoder.h"

namespace qifeng::scm {

    ScmCommand SlogHandler::GetCommand() const {
        return ScmCommand::SLOG;
    }

    ScmResponse SlogHandler::Handle(const ScmRequest& request,
                                    const ServiceContext& ctx,
                                    KeyOperationRecorder& /*recorder*/) {
        const auto* params = std::get_if<SlogRequest>(&request.data);
        if (params == nullptr || params->serviceName.empty()) {
            SLOG_WARN << "Slog command missing service name";
            ScmResponse response;
            response.code = -1;
            response.message = "Slog command requires service name";
            return response;
        }

        ScmResponse response;
        auto result = service_operations::GetServiceLog(ctx, params->serviceName, params->logCount);
        response.code = result.code;
        response.message = result.msg;
        return response;
    }

    REGISTER_COMMAND_HANDLER(ScmCommand::SLOG, SlogHandler)

}  // namespace qifeng::scm
