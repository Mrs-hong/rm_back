/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "scmd/handlers/reload_all_handler.h"

#include "common/types.h"
#include "ipc/data_def.h"
#include "scmd/handler_registry.h"
#include "service_manager/key_recoder.h"
#include "service_manager/service_manager.h"

namespace qifeng::scm {

    ScmCommand ReloadAllHandler::GetCommand() const {
        return ScmCommand::RELOAD_ALL;
    }

    ScmResponse ReloadAllHandler::Handle(const ScmRequest& /*request*/,
                                         const ServiceContext& ctx,
                                         KeyOperationRecorder& /*recorder*/) {
        ScmResponse response;
        // 使用空服务名表示重载全部服务配置
        auto result = ctx.serviceManager->ReloadService("");
        response.code = result.code;
        response.message = result.msg;
        return response;
    }

    REGISTER_COMMAND_HANDLER(ScmCommand::RELOAD_ALL, ReloadAllHandler)

}  // namespace qifeng::scm
