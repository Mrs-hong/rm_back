/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "scmd/service_operations.h"

#include "common/config.h"
#include "common/types.h"
#include "common/utils/path.h"
#include "qifeng_framework/common/logger.h"
#include "service_manager/database_service.h"
#include "service_manager/file_manager.h"
#include "service_manager/service_manager.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <string>
#include <systemd/sd-journal.h>
#include <thread>
#include <vector>

namespace qifeng::scm::service_operations {

    ResultMsg InstallServiceWithDb(const ServiceContext &ctx, const std::string &serviceName,
                                   const std::string &tarPath) {
        SLOG_INFO << "Installing service: " << serviceName << " from " << tarPath;
        auto result = ctx.serviceManager->InstallService(tarPath, serviceName);
        if (!result.IsDefalutSuccess()) {
            // 安装失败，直接返回错误
            SLOG_ERROR << "Failed to install service: " << serviceName << " from " << tarPath
                       << ", error: " << result.msg;
            return result;
        }

        // 安装成功，msg 为实际服务名，继续后续处理（数据库初始化、启动验证）
        std::string actualServiceName = result.msg;

        // 先初始化数据库：服务运行通常依赖数据库，必须在启动验证前完成初始化
        result = ctx.databaseService->InitServiceDatabase(actualServiceName);
        if (!result.IsDefalutSuccess()) {
            // 数据建库操作失败，回滚安装
            UninstallServiceWithCleanup(ctx, actualServiceName);
            return MakeError("install service " + actualServiceName + " failed: " + result.msg);
        }

        // 数据库初始化成功后，按 keep_alive_time_sec 进行启动验证
        // 验证失败仅返回警告（code=1），不回滚安装（数据库已就绪，便于用户排查）
        auto *installedSvc = ctx.configLoader->GetServiceByName(actualServiceName);
        uint32_t keepSec = installedSvc ? installedSvc->keepAliveTimeSec : 0;
        if (keepSec > 0) {
            SLOG_INFO << "Verifying installed service keeps running for " << keepSec << "s: " << actualServiceName;
            auto startRet = ctx.serviceManager->StartService(actualServiceName);
            if (!startRet.IsDefalutSuccess()) {
                SLOG_WARN << "Installed service failed to start: " << startRet.msg;
                return MakeWarning(actualServiceName + " installed, but failed to start: " + startRet.msg);
            }
            std::this_thread::sleep_for(std::chrono::seconds(keepSec));
            if (!ctx.serviceManager->IsServiceActive(actualServiceName)) {
                SLOG_WARN << "Installed service is not active after " << keepSec << "s: " << actualServiceName;
                return MakeWarning(actualServiceName + " installed, but not active after " +
                                   std::to_string(keepSec) + "s verification");
            }
            SLOG_INFO << "Installed service verified running for " << keepSec << "s: " << actualServiceName;
        } else {
            SLOG_INFO << "Skip install verification (keep_alive_time_sec=0): " << actualServiceName;
        }

        return MakeSuccess();
    }

    ResultMsg UninstallServiceWithCleanup(const ServiceContext &ctx, const std::string &serviceName) {
        SLOG_INFO << "Uninstalling service: " << serviceName;
        auto svc = ctx.configLoader->GetServiceByName(serviceName);
        if (svc == nullptr) {
            return MakeError("Service not found: " + serviceName);
        }

        // 先清除数据库相关（在删除服务文件之前，以便读取密码文件发现所有数据库）
        if (svc->dbInfo.dbType != DatabaseType::NONE) {
            ResultMsg result = ctx.databaseService->ClearDatabaseData(*svc);
            if (result.code == -1) {
                return MakeError("clear database data failed:" + result.msg);
            }
        }

        // 卸载服务（停止服务 + 删除服务文件 + 从配置中移除）
        ResultMsg ret = ctx.serviceManager->UninstallService(serviceName);
        if (ret.code == -1) {
            return MakeError("uninstall service failed:" + ret.msg);
        }
        return ret;
    }

    ResultMsg RestartAllServices(const ServiceContext &ctx) {
        SLOG_INFO << "Restarting all services";

        // 先停止所有服务
        auto stopResult = ctx.serviceManager->StopAllServices();
        if (!stopResult.IsDefalutSuccess()) {
            SLOG_WARN << "Some services failed to stop: " << stopResult.msg;
        }

        // 再启动所有autoStart服务
        auto startResult = ctx.serviceManager->StartAllAutoStartServices();
        if (!startResult.IsDefalutSuccess()) {
            SLOG_WARN << "Some services failed to start: " << startResult.msg;
        }

        if (!stopResult.IsDefalutSuccess() || !startResult.IsDefalutSuccess()) {
            return MakeWarning("Some services failed during restart");
        }

        SLOG_INFO << "All services restarted successfully";
        return MakeSuccess();
    }

    ResultMsg GetOperationLog(const ServiceContext &ctx, int /*logLevel*/, int logCount) {
        const auto &configInfo = ctx.configLoader->GetConfigInfo();
        std::string logPath = utils::JoinPath(configInfo.logsDir, "scmd.log");

        std::ifstream logFile(logPath);
        if (!logFile.is_open()) {
            return MakeError("Log file not found: " + logPath);
        }

        // 读取所有行，返回最后logCount行内容
        std::vector<std::string> lines;
        std::string line;
        while (std::getline(logFile, line)) {
            lines.push_back(line);
        }
        logFile.close();

        int startIdx =
            logCount > 0 && static_cast<int>(lines.size()) > logCount ? static_cast<int>(lines.size()) - logCount : 0;

        // 将日志内容拼接到msg中
        std::string logContent;
        for (int i = startIdx; i < static_cast<int>(lines.size()); ++i) {
            if (i > startIdx) {
                logContent += "\n";
            }
            logContent += lines[static_cast<size_t>(i)];
        }

        ResultMsg result;
        result.code = 0;
        result.msg = logContent.empty() ? "No log entries" : logContent;
        return result;
    }

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg GetServiceLog(const ServiceContext &ctx, const std::string &serviceName, int logCount) {
        if (serviceName.empty()) {
            return MakeError("Service name is empty");
        }
        // 校验服务已注册，避免查询任意系统服务
        if (ctx.configLoader->GetServiceByName(serviceName) == nullptr) {
            return MakeError("Service not found: " + serviceName);
        }

        // 行数边界处理：<=0 时使用默认 10
        int count = logCount > 0 ? logCount : 10;

        // 构造 systemd 单元名（scmd_ + serviceName），与 service_utils::ToSystemdUnitName 规则一致
        std::string unitName = std::string(FileManager::GetServiceFilePrefix()) + serviceName;

        // sd-journal 句柄使用 RAII 确保释放
        sd_journal *journal = nullptr;
        auto cleanup = [&journal]() {
            if (journal != nullptr) {
                sd_journal_close(journal);
                journal = nullptr;
            }
        };

        // 打开本地 journal
        int r = sd_journal_open(&journal, SD_JOURNAL_LOCAL_ONLY);
        if (r < 0) {
            SLOG_ERROR << "Failed to open journal: " << strerror(-r);
            return MakeError("Failed to open journal: " + std::string(strerror(-r)));
        }

        // 取消数据阈值限制：默认阈值会截断长字段（如 MESSAGE），
        // 设为 0 表示无限制，确保 MESSAGE 完整返回（与 journalctl 输出一致）
        sd_journal_set_data_threshold(journal, 0);

        // 添加单元过滤条件：_SYSTEMD_UNIT=<unit>.service
        std::string match = "_SYSTEMD_UNIT=" + unitName + ".service";
        r = sd_journal_add_match(journal, match.c_str(), 0);
        if (r < 0) {
            SLOG_ERROR << "Failed to add journal match: " << strerror(-r);
            cleanup();
            return MakeError("Failed to add journal match: " + std::string(strerror(-r)));
        }

        // 跳到日志末尾，向前读取最近 count 条
        r = sd_journal_seek_tail(journal);
        if (r < 0) {
            SLOG_ERROR << "Failed to seek journal tail: " << strerror(-r);
            cleanup();
            return MakeError("Failed to seek journal tail: " + std::string(strerror(-r)));
        }

        // entries 按从新到旧收集，最后反转为从旧到新（与 journalctl -n 输出顺序一致）
        std::vector<std::string> entries;
        entries.reserve(static_cast<size_t>(count));

        // 辅助：从 journal 当前条目获取指定字段值（去掉 "FIELD=" 前缀）
        auto getJournalField = [&journal](const char *field) -> std::string {
            const void *data = nullptr;
            size_t length = 0;
            int ret = sd_journal_get_data(journal, field, &data, &length);
            if (ret < 0) {
                return {};
            }
            size_t prefixLen = strlen(field) + 1;  // +1 跳过 '='
            return std::string(static_cast<const char *>(data) + prefixLen, length - prefixLen);
        };

        // 辅助：将微秒时间戳转为 "MMM DD HH:MM:SS" 格式（如 "Jul 09 21:41:32"）
        auto formatTimestamp = [](uint64_t usec) -> std::string {
            time_t sec = static_cast<time_t>(usec / 1000000U);
            struct tm timeInfo {};
            localtime_r(&sec, &timeInfo);
            static const std::array<const char *, 12> MonthAbbr = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                                                  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
            int mon = timeInfo.tm_mon;
            const char *monthStr = (mon >= 0 && mon < 12) ? MonthAbbr[static_cast<size_t>(mon)] : "???";
            std::ostringstream oss;
            oss << monthStr << " " << std::setw(2) << std::setfill('0') << timeInfo.tm_mday << " " << std::setw(2)
                << std::setfill('0') << timeInfo.tm_hour << ":" << std::setw(2) << std::setfill('0') << timeInfo.tm_min
                << ":" << std::setw(2) << std::setfill('0') << timeInfo.tm_sec;
            return oss.str();
        };

        while (static_cast<int>(entries.size()) < count) {
            r = sd_journal_previous(journal);
            if (r == 0) {
                break;  // 到达日志开头
            }
            if (r < 0) {
                SLOG_ERROR << "Failed to iterate journal: " << strerror(-r);
                cleanup();
                return MakeError("Failed to iterate journal: " + std::string(strerror(-r)));
            }

            // 提取各字段：时间戳、主机名、进程标识符、PID、消息正文
            std::string tsStr;
            // 使用 sd_journal_get_realtime_usec 获取实时时间戳（微秒），
            // 比通过 __REALTIME_TIMESTAMP 字段解析更可靠（后者可能返回空导致无时间戳前缀）
            uint64_t usec = 0;
            int tr = sd_journal_get_realtime_usec(journal, &usec);
            if (tr >= 0) {
                tsStr = formatTimestamp(usec);
            }

            std::string hostname = getJournalField("_HOSTNAME");
            // 进程标识符：优先 SYSLOG_IDENTIFIER，回退 _COMM
            std::string identifier = getJournalField("SYSLOG_IDENTIFIER");
            if (identifier.empty()) {
                identifier = getJournalField("_COMM");
            }
            std::string pidStr = getJournalField("_PID");
            std::string message = getJournalField("MESSAGE");
            if (message.empty()) {
                continue;  // 无 MESSAGE 则跳过
            }

            // 组装为 journalctl -o short 格式: "MMM DD HH:MM:SS hostname identifier[pid]: message"
            // 示例: "Jul 09 21:41:32 bm1684 qifeng_ca[5630]: error message..."
            std::ostringstream line;
            if (!tsStr.empty()) {
                line << tsStr << " ";
            }
            if (!hostname.empty()) {
                line << hostname << " ";
            }
            if (!identifier.empty()) {
                line << identifier;
                if (!pidStr.empty()) {
                    line << "[" << pidStr << "]";
                }
                line << ": ";
            }
            line << message;
            entries.push_back(line.str());
        }

        cleanup();

        // 反转为从旧到新，逐行拼接（每条一行，末尾保留换行）
        std::reverse(entries.begin(), entries.end());
        std::string output;
        for (const auto &entry : entries) {
            output += entry + "\n";
        }

        ResultMsg result;
        result.code = 0;
        result.msg = output;
        return result;
    }

    ResultMsg ClearServiceDataWithDb(const ServiceContext &ctx, const std::string &serviceName) {
        auto svc = ctx.configLoader->GetServiceByName(serviceName);
        if (svc == nullptr) {
            return MakeError("Service not found: " + serviceName);
        }
        // 先清除数据库相关（在删除服务数据之前，以便读取密码文件）
        if (svc->dbInfo.dbType != DatabaseType::NONE) {
            ResultMsg result = ctx.databaseService->ClearDatabaseData(*svc);
            if (result.code == -1) {
                return MakeError("clear database data failed:" + result.msg);
            }
        }
        ctx.serviceManager->ClearServiceData(serviceName);
        return MakeSuccess();
    }

}  // namespace qifeng::scm::service_operations
