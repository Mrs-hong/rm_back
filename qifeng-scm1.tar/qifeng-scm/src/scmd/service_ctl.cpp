/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "scmd/service_ctl.h"

#include "common/config.h"
#include "common/scmd_def.h"
#include "common/scmd_types.h"
#include "common/types.h"
#include "common/utils/path.h"
#include "common/utils/path_migration.h"
#include "qifeng_framework/common/logger.h"
#include "service_manager/database_service.h"
#include "service_manager/model_manager.h"
#include "service_manager/nginx_manager.h"
#include "service_manager/service_manager.h"
#include "service_manager/upgrade_service.h"

namespace qifeng::scm {

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg ServiceControl::Init() {
        mConfigLoader = std::make_shared<ConfigLoader>();
        auto result = mConfigLoader->Initialize();
        if (!result.IsDefalutSuccess() && result.code != 1) {
            return MakeError("Failed to initialize ConfigLoader: " + result.msg);
        }

        // 启动时路径迁移：读取 preinst 生成的 scmd.yaml.back，若新旧 root_dir/model_dir
        // 不一致则迁移数据并重定向软链接。必须在 ServiceManager 构造（会创建目录）前完成。
        auto migrateResult = MigratePathsIfNeeded();
        if (!migrateResult.IsDefalutSuccess()) {
            SLOG_WARN << "Path migration completed with warnings: " << migrateResult.msg;
        }

        const auto &configInfo = mConfigLoader->GetConfigInfo();
        auto logFileSizeBytes = static_cast<size_t>(configInfo.logFileSizeMB) * 1024U * 1024U;
        Logger::GetInstance().Initialize(configInfo.logsDir, "scmd.log", logFileSizeBytes, configInfo.logFileCount);
        SLOG_INFO << "ServiceControl initializing...";

        mServiceManager = std::make_shared<ServiceManager>(mConfigLoader);

        // 构造 ServiceContext：从 ServiceManager 获取基础依赖上下文
        // （configLoader/fileManager/dbusManager），并回填 serviceManager 指针。
        // 领域服务（databaseService、nginxManager、modelManager、upgradeService）按依赖顺序构造后填充。
        mContext = mServiceManager->GetServiceContext();
        mContext.serviceManager = mServiceManager;

        // 构造 DatabaseService：升级流程通过 UpgradeService 持有其引用调用。
        mContext.databaseService = std::make_shared<DatabaseService>(mContext);

        // 构造 NginxManager：handler 通过 ServiceContext::nginxManager 直接访问。
        mContext.nginxManager = std::make_shared<NginxManager>(mContext);

        // 构造 ModelManager：handler 通过 ServiceContext::modelManager 直接访问。
        // 需在 serviceManager 填充后构造（ModelManager 通过 mCtx.serviceManager 调用启停能力）。
        mContext.modelManager = std::make_shared<ModelManager>(mContext);

        // 构造 UpgradeService：handler 通过 ServiceContext::upgradeService 直接访问。
        // 需在 serviceManager/modelManager/nginxManager/databaseService 均就绪后构造
        // （UpgradeService 持有它们的引用）。
        mContext.upgradeService = std::make_shared<::qifeng::scm::UpgradeService>(
            mContext, *mContext.serviceManager, *mContext.modelManager, *mContext.nginxManager, *mContext.databaseService);

        auto allServices = mConfigLoader->GetAllServices();
        if (allServices.empty()) {
            SLOG_INFO << "No installed services found, skip auto-start";
        } else {
            SLOG_INFO << "Found " << allServices.size() << " installed service(s), starting auto-start services...";
            result = mServiceManager->StartAllAutoStartServices();
            if (!result.IsDefalutSuccess()) {
                SLOG_WARN << "Some auto-start services failed: " << result.msg;
            }
        }

        mIsInit = true;
        SLOG_INFO << "ServiceControl initialized successfully";
        return MakeSuccess();
    }

    const ConfigLoader &ServiceControl::GetConfigLoader() const {
        return *mConfigLoader;
    }

    const ServiceContext &ServiceControl::GetServiceContext() const {
        return mContext;
    }

    // NOLINTNEXTLINE(readability-function-size, readability-function-cognitive-complexity)
    ResultMsg ServiceControl::MigratePathsIfNeeded() {
        // 备份配置路径：preinst 在升级时将旧 scmd.yaml 重命名为 scmd.yaml.back
        const std::string backupPath = std::string(DefaultConfigPath) + ".back";

        // 解析旧路径；备份不存在（全新安装）或解析失败均视为无需迁移，不阻断启动
        utils::OldPathInfo oldInfo;
        auto parseRet = utils::ParseOldPathsFromBackup(backupPath, oldInfo);
        if (!parseRet.IsDefalutSuccess()) {
            SLOG_INFO << "MigratePathsIfNeeded: no backup config or parse failed, skip: " << parseRet.msg;
            return MakeSuccess();
        }

        const auto &configInfo = mConfigLoader->GetConfigInfo();
        std::string warnings;

        // root_dir 变更：迁移子目录内容并重定向 systemd/nginx 软链接
        if (!oldInfo.rootDir.empty() &&
            utils::NormalizePath(oldInfo.rootDir) != utils::NormalizePath(configInfo.rootDir)) {
            SLOG_INFO << "MigratePathsIfNeeded: root_dir changed " << oldInfo.rootDir << " -> " << configInfo.rootDir;

            auto rootRet = utils::MigrateRootDirContents(oldInfo.rootDir, configInfo.rootDir);
            if (!rootRet.IsDefalutSuccess()) {
                warnings += "root_dir migrate failed: " + rootRet.msg + "; ";
            }

            // systemd 单元软链接指向 <rootDir>/services/.init，需随迁移重定向
            std::string oldInitDir = utils::JoinPath(oldInfo.rootDir, "services", ".init");
            std::string newInitDir = utils::JoinPath(configInfo.rootDir, "services", ".init");
            auto sdRet = utils::RepointSystemdSymlinks(oldInitDir, newInitDir);
            if (!sdRet.IsDefalutSuccess()) {
                warnings += "repoint systemd symlinks failed: " + sdRet.msg + "; ";
            }

            // nginx 配置软链接指向 <rootDir>/services，需随迁移重定向
            std::string oldServiceDir = utils::JoinPath(oldInfo.rootDir, "services");
            std::string newServiceDir = utils::JoinPath(configInfo.rootDir, "services");
            auto ngRet = utils::RepointNginxSymlinks(oldServiceDir, newServiceDir);
            if (!ngRet.IsDefalutSuccess()) {
                warnings += "repoint nginx symlinks failed: " + ngRet.msg + "; ";
            }
        }

        // model_dir 变更：迁移模型目录内容
        if (!oldInfo.modelDir.empty() &&
            utils::NormalizePath(oldInfo.modelDir) != utils::NormalizePath(configInfo.modelDir)) {
            SLOG_INFO << "MigratePathsIfNeeded: model_dir changed " << oldInfo.modelDir << " -> "
                      << configInfo.modelDir;
            auto modelRet = utils::MigrateModelDir(oldInfo.modelDir, configInfo.modelDir);
            if (!modelRet.IsDefalutSuccess()) {
                warnings += "model_dir migrate failed: " + modelRet.msg + "; ";
            }
        }

        if (!warnings.empty()) {
            SLOG_WARN << "MigratePathsIfNeeded completed with warnings: " << warnings;
            return MakeWarning(warnings);
        }
        SLOG_INFO << "MigratePathsIfNeeded: no migration needed or completed successfully";
        return MakeSuccess();
    }

}  // namespace qifeng::scm
