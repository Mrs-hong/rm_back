/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "scmd/handler_registry.h"

#include <algorithm>
#include <type_traits>

#include "ipc/data_def.h"
#include "qifeng_framework/common/logger.h"

namespace qifeng::scm {

    HandlerRegistry& HandlerRegistry::Instance() {
        // Meyers 单例：函数内静态局部变量，线程安全的初始化保证
        static HandlerRegistry Instance;
        return Instance;
    }

    void HandlerRegistry::Register(ScmCommand cmd, HandlerFactory factory) {
        if (mFactories.find(cmd) != mFactories.end()) {
            // 同一命令重复注册，输出错误日志并忽略后一次，保留先注册的工厂
            SLOG_ERROR << "Duplicate handler factory registration ignored: " << ScmCommandToString(cmd);
            return;
        }

        mFactories.emplace(cmd, std::move(factory));
    }

    std::vector<std::unique_ptr<ICommandHandler>> HandlerRegistry::BuildAll(const HandlerContext& ctx) const {
        std::vector<std::unique_ptr<ICommandHandler>> handlers;
        handlers.reserve(mFactories.size());

        // 按 cmd 排序以保证构造顺序确定，避免依赖 unordered_map 的迭代顺序
        std::vector<ScmCommand> cmds;
        cmds.reserve(mFactories.size());
        for (const auto& [cmd, factory] : mFactories) {
            cmds.push_back(cmd);
        }
        std::sort(cmds.begin(), cmds.end(), [](ScmCommand a, ScmCommand b) {
            return static_cast<std::underlying_type_t<ScmCommand>>(a)
                 < static_cast<std::underlying_type_t<ScmCommand>>(b);
        });

        for (auto cmd : cmds) {
            const auto& factory = mFactories.at(cmd);
            handlers.push_back(factory(ctx));
        }

        return handlers;
    }

}  // namespace qifeng::scm
