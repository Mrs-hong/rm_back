/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#pragma once

#include "common/types.h"
#include "ipc/data_def.h"

#include <string>

namespace qifeng::scm {

    /**
     * @brief SN码校验码计算与校验
     * @details 仅负责 SN 码校验码的生成与校验，无 WiFi 配置、无 /etc/device-info 读写、
     *          无 root 校验、无时间相关前缀组装，可在任意用户/任意环境离线运行。
     *          不走UDS，由 qf_scmc 本地直接执行。
     *          SN格式: 型号(2) + 年份(2) + 月份(2) + 工厂码(2) + 流水号(6) + 校验码(2) = 16位
     *          校验码: 前14位经SHA256摘要，取前8位hex转uint32后mod 100，格式化为2位十进制
     */
    class SnCodec {
    public:
        SnCodec() = default;
        ~SnCodec() = default;

        SnCodec(const SnCodec &) = delete;
        SnCodec &operator=(const SnCodec &) = delete;
        SnCodec(SnCodec &&) = delete;
        SnCodec &operator=(SnCodec &&) = delete;

        /**
         * @brief 根据前14位生成完整16位SN码
         * @param prefix SN前14位（型号+年月+工厂码+流水号）
         * @return ScmResponse code=0成功(message为完整16位SN), code=-1失败(message含原因)
         * @details 校验前14位格式 → 生成2位校验码 → 拼接返回完整16位SN。
         *          返回 message 不含 "[OK] " 前缀，由 FormatOutput 统一添加。
         */
        ScmResponse Calculate(const std::string &prefix);

        /**
         * @brief 校验完整16位SN码是否合法
         * @param sn 待校验的完整16位SN码
         * @return ScmResponse code=0合法, code=-1非法(message含原因)
         * @details 校验长度16、各字段格式（型号大写字母/年月工厂流水号为数字/月份01-12）、校验码匹配。
         *          返回 message 不含 "[OK]/[FAIL] " 前缀，由 FormatOutput 统一添加。
         */
        ScmResponse Verify(const std::string &sn);

    private:
        /**
         * @brief 根据前14位生成2位十进制校验码
         * @param prefix SN前14位（仅含[A-Z0-9]）
         * @param checkCode 输出2位十进制校验码
         * @return ResultMsg 成功/失败
         * @details 通过 sha256sum 计算 SHA256 摘要，取前8位hex转uint32后mod 100。
         */
        ResultMsg GenCheckCode(const std::string &prefix, std::string &checkCode);

        /**
         * @brief 校验SN前14位格式
         * @param prefix SN前14位
         * @return ResultMsg 成功表示合规，失败msg含原因
         * @details 校验长度14、型号大写字母、年月工厂流水号为数字、月份01-12。
         */
        ResultMsg ValidatePrefix(const std::string &prefix);

        /**
         * @brief 校验完整16位SN码格式
         * @param sn 待校验的16位SN码
         * @return ResultMsg 成功表示格式合规，失败msg含原因
         * @details 校验长度16、前14位调用 ValidatePrefix、校验码2位为数字。
         */
        ResultMsg ValidateFormat(const std::string &sn);
    };

}  // namespace qifeng::scm
