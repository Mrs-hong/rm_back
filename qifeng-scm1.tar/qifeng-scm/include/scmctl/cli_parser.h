/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */
#pragma once

#include "common/types.h"
#include "ipc/data_def.h"

#include <memory>
#include <vector>

namespace qifeng::scm {

    // 前向声明：本地命令基类（定义于 cli_commands.h），保持本头文件轻量
    class LocalCliCommand;

    /**
     * @brief 命令行参数解析器
     * @details 使用 qifeng_framework 提供的 CLI11 解析命令行参数，根据 ipc/commd.md 定义命令，
     * 若符合则生成 ScmRequest（走UDS），否则通过 ResultMsg 返回错误信息。
     * 另支持本地命令（LocalCliCommand，不走UDS），命中后由 main 调用 ExecuteLocal 直接执行。
     */
    class CliParser {
    public:
        CliParser();
        /**
         * @brief 析构函数声明于头文件，定义于 cpp（此处 LocalCliCommand 为完整类型，
         *        保证 std::unique_ptr<LocalCliCommand> 成员可析构）
         */
        ~CliParser();

        CliParser(const CliParser &) = delete;
        CliParser &operator=(const CliParser &) = delete;
        CliParser(CliParser &&) = delete;
        CliParser &operator=(CliParser &&) = delete;

        /**
         * @brief 解析命令行参数
         * @param argc 参数个数
         * @param argv 参数数组
         * @return ResultMsg
         *         code=0: 解析成功，通过 GetRequest() 获取请求或 HasLocalCommand() 判断本地命令
         *         code=1: 需要输出 msg 后退出（--help/--version/无子命令）
         *         code=-1: 解析错误，msg 包含错误信息
         */
        ResultMsg Parse(int argc, char** argv);

        /**
         * @brief 获取解析后的请求（仅对走UDS的远程命令有效）
         * @return const ScmRequest& 请求引用
         */
        const ScmRequest &GetRequest() const;

        /**
         * @brief 是否命中本地命令（不走UDS）
         * @return bool true 表示命中本地命令，应调用 ExecuteLocal()
         */
        bool HasLocalCommand() const;

        /**
         * @brief 执行命中的本地命令
         * @return ScmResponse 本地执行结果，由调用方格式化输出
         * @details 调用前需确认 HasLocalCommand() 为 true，否则返回默认响应
         */
        ScmResponse ExecuteLocal();

    private:
        ScmRequest mRequest;                                           // 远程命令请求
        bool mHasLocal {false};                                        // 是否命中本地命令
        std::vector<std::unique_ptr<LocalCliCommand>> mLocalCommands;  // 本地命令集合（拥有所有权）
        LocalCliCommand* mMatchedLocal {nullptr};                      // 命中的本地命令（非拥有指针）
    };

}  // namespace qifeng::scm
