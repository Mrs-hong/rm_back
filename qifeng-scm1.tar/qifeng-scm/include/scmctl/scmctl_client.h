/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#pragma once

#include "common/types.h"
#include "ipc/data_def.h"
#include <string>

namespace qifeng::scm {
    /**
     * @brief SCMD 控制客户端
     * @details CliParser解析命令行参数后，使用UDS功能块与scmd通信，并将结果输出到终端
     */
    class ScmCtlClient {
    public:
        ScmCtlClient() = default;
        ~ScmCtlClient() = default;

        ScmCtlClient(const ScmCtlClient &) = delete;
        ScmCtlClient &operator=(const ScmCtlClient &) = delete;
        ScmCtlClient(ScmCtlClient &&) = delete;
        ScmCtlClient &operator=(ScmCtlClient &&) = delete;

        /**
         * @brief 发送请求并接收响应
         * @param request 请求结构体
         * @param socketPath UDS socket路径
         * @return ScmResponse 响应结构体
         */
        ScmResponse SendRequest(const ScmRequest &request, const std::string &socketPath);

        /**
         * @brief 本地控制 qf_scmd 自身（直接调用 systemctl，不走 UDS）
         * @details 当 start/stop/restart 未指定 -n 时，由客户端直接通过 systemctl 控制
         *          qifeng_scmd.service 守护进程，避免守护进程未运行或自我停止时的 UDS/DBus 死锁。
         *          需要 root 权限，非 root 用户将收到 systemctl 的认证错误。
         * @param cmd 命令类型（仅支持 START/STOP/RESTART）
         * @return ScmResponse 执行结果，code=0 成功，code=-1 失败（message 携带 systemctl 输出）
         */
        ScmResponse ControlScmdSelf(ScmCommand cmd) const;

        /**
         * @brief 格式化响应输出到终端
         * @param response 响应结构体
         * @return ResultMsg 格式化结果结构体
         * @details 格式化响应结构体，根据code字段判断是否成功，成功则输出成功信息，失败则输出错误信息
         */
        ResultMsg FormatOutput(const ScmResponse &response);
    };
}  // namespace qifeng::scm
