/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#pragma once

#include <string>

namespace qifeng::scm {
    class ConfigLoader;

    /**
     * @brief 开机自检服务
     * @details 从 ScmServer 抽出的自检职责：读取自检开关/路径、加载 selftest.json、
     *          运行 CheckerRunner、根据 fail_action 决定是否阻止启动。
     *          在 ScmServer::Start 之前由 main 调用。
     */
    class SelfCheckService {
    public:
        /**
         * @brief 构造函数
         * @param configLoader 配置加载器引用，用于读取自检配置
         */
        explicit SelfCheckService(const ConfigLoader& configLoader);

        /**
         * @brief 执行开机自检
         * @return true 自检通过或仅告警，可以继续启动；false 自检失败且 fail_action=halt，应中止启动
         */
        bool Run();

    private:
        const ConfigLoader& mConfigLoader;
        std::string mSelfTestConfigPath;  // 自检配置文件路径
    };
}  // namespace qifeng::scm
