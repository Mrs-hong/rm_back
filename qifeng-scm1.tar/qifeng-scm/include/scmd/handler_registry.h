/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#pragma once

#include "scmd/command_handler.h"

#include <memory>
#include <unordered_map>
#include <vector>

namespace qifeng::scm {

    /**
     * @brief 命令处理器注册表（单例）
     * @details 各 handler.cpp 通过 REGISTER_COMMAND_HANDLER 宏在静态初始化期自注册工厂函数。
     *          CommandDispatcher::LoadFromRegistry 调用 BuildAll 统一构造所有 handler 实例，
     *          消除 ScmServer 中手工列举 handler 的脚手架代码。
     */
    class HandlerRegistry {
    public:
        /**
         * @brief 获取单例实例
         */
        static HandlerRegistry& Instance();

        ~HandlerRegistry() = default;
        HandlerRegistry(const HandlerRegistry&) = delete;
        HandlerRegistry& operator=(const HandlerRegistry&) = delete;
        HandlerRegistry(HandlerRegistry&&) = delete;
        HandlerRegistry& operator=(HandlerRegistry&&) = delete;

        /**
         * @brief 注册处理器工厂
         * @param cmd 命令枚举值
         * @param factory 工厂函数，接收 HandlerContext 返回 handler 实例
         * @details 若同一命令重复注册，输出错误日志并忽略后一次。
         */
        void Register(ScmCommand cmd, HandlerFactory factory);

        /**
         * @brief 构造所有已注册的 handler 实例
         * @param ctx handler 构造上下文
         * @return 按 cmd 排序的 handler 实例列表
         */
        std::vector<std::unique_ptr<ICommandHandler>> BuildAll(const HandlerContext& ctx) const;

    private:
        HandlerRegistry() = default;

        std::unordered_map<ScmCommand, HandlerFactory> mFactories;
    };

    /**
     * @brief 命令处理器自注册宏
     * @param cmd ScmCommand 枚举值
     * @param HandlerClass 处理器类名
     * @details 在 .cpp 文件末尾使用，通过静态初始化将工厂函数注册到 HandlerRegistry。
     *          要求 HandlerClass 具有接受 const HandlerContext& 的构造函数。
     */
    #define REGISTER_COMMAND_HANDLER(cmd, HandlerClass)                                  \
        namespace {                                                                       \
            const bool g_reg_##HandlerClass = []() {                                      \
                ::qifeng::scm::HandlerRegistry::Instance().Register(                      \
                    cmd,                                                                  \
                    [](const ::qifeng::scm::HandlerContext& ctx)                          \
                        -> std::unique_ptr<::qifeng::scm::ICommandHandler> {              \
                        return std::make_unique<HandlerClass>(ctx);                       \
                    });                                                                   \
                return true;                                                              \
            }();                                                                          \
        }

}  // namespace qifeng::scm
