/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#pragma once

#include "scmd/command_handler.h"

#include <memory>
#include <unordered_map>

namespace qifeng::scm {

    /**
     * @brief 命令分发器
     * @details 维护 ScmCommand 到 ICommandHandler 的映射，根据请求类型分发给对应处理器。
     *          handler 实例由 HandlerRegistry 统一构造，通过 LoadFromRegistry 装载，
     *          新增命令时只需新增 handler 并自注册，无需修改 ScmServer 核心逻辑。
     */
    class CommandDispatcher {
    public:
        CommandDispatcher() = default;
        ~CommandDispatcher() = default;

        CommandDispatcher(const CommandDispatcher&) = delete;
        CommandDispatcher& operator=(const CommandDispatcher&) = delete;
        CommandDispatcher(CommandDispatcher&&) = delete;
        CommandDispatcher& operator=(CommandDispatcher&&) = delete;

        /**
         * @brief 注册单个命令处理器（高级/测试用法）
         * @param handler 处理器实例，由分发器接管所有权
         * @details 正常场景应使用 LoadFromRegistry 从注册表统一装载。
         *          此方法供单元测试和需要手动注册处理器的场景使用。
         */
        void Register(std::unique_ptr<ICommandHandler> handler);

        /**
         * @brief 从 HandlerRegistry 装载所有已注册的处理器
         * @param ctx handler 构造上下文，传递给各 handler 的工厂函数
         * @details 调用 HandlerRegistry::Instance().BuildAll(ctx) 构造全部 handler 实例并建立映射。
         *          同一命令重复注册时输出错误日志并跳过后一次。
         */
        void LoadFromRegistry(const HandlerContext& ctx);

        /**
         * @brief 分发请求到对应处理器
         * @param request 已解析的请求对象
         * @param ctx 共享服务上下文，透传给处理器
         * @param recorder 关键操作记录器
         * @return 命令执行结果响应；若命令未注册则返回 Unknown command 错误。
         */
        ScmResponse Dispatch(const ScmRequest& request,
                             const ServiceContext& ctx,
                             KeyOperationRecorder& recorder) const;

        /**
         * @brief 分发操作恢复请求到对应处理器
         * @param record 关键操作记录，通过 optName 定位处理器
         * @param ctx 共享服务上下文，透传给处理器
         * @return 恢复结果；若操作名无法解析或无对应处理器则返回警告。
         */
        ResultMsg Recover(const KeyOperationRecord& record, const ServiceContext& ctx) const;

    private:
        std::unordered_map<ScmCommand, std::unique_ptr<ICommandHandler>> mHandlers;
    };

}  // namespace qifeng::scm
