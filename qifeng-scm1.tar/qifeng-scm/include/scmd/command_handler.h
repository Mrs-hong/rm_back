/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#pragma once

#include "common/types.h"
#include "ipc/data_def.h"
#include "service_manager/key_recoder.h"
#include "service_manager/service_context.h"

#include <functional>
#include <memory>
#include <string>

namespace qifeng::scm {

    // 前向声明，供 HandlerFactory 类型别名使用
    class ICommandHandler;

    /**
     * @brief 命令处理器构造上下文
     * @details 由 ScmServer 在装配阶段填充，传递给 HandlerFactory 用于构造 handler 实例。
     *          handler 通过此上下文获取自检配置路径与关闭回调等运行时资源，避免直接依赖 ScmServer。
     */
    struct HandlerContext {
        std::string selfTestConfigPath;      // 自检配置文件路径（CHECK 命令默认使用）
        std::function<void()> shutdownCallback;  // 优雅关闭回调（KILL 命令触发 scmd 退出）
    };

    /**
     * @brief 命令处理器工厂函数类型
     * @details 接收 HandlerContext，返回一个 ICommandHandler 实例。
     *          各 handler 通过 REGISTER_COMMAND_HANDLER 宏自注册此类型工厂。
     */
    using HandlerFactory = std::function<std::unique_ptr<ICommandHandler>(const HandlerContext&)>;

    /**
     * @brief 命令处理器抽象接口
     * @details 每个 ScmCommand 对应一个实现类，负责参数校验、业务调用和响应组装。
     *          通过此接口将 scmd_server.cpp 中的巨型 switch-case 拆分为独立的处理器。
     *
     *          handler 通过 ServiceContext 直接访问子服务，不再经过 ServiceControl 门面；
     *          Recover 提供操作恢复的默认实现（返回警告），支持子类按需覆盖。
     */
    class ICommandHandler {
    public:
        virtual ~ICommandHandler() = default;

        ICommandHandler() = default;
        ICommandHandler(const ICommandHandler&) = delete;
        ICommandHandler& operator=(const ICommandHandler&) = delete;
        ICommandHandler(ICommandHandler&&) = delete;
        ICommandHandler& operator=(ICommandHandler&&) = delete;

        /**
         * @brief 获取该处理器负责的命令类型
         * @return 对应的 ScmCommand 枚举值
         */
        virtual ScmCommand GetCommand() const = 0;

        /**
         * @brief 处理命令请求
         * @param request 已解析的请求对象
         * @param ctx 共享服务上下文，提供各领域子服务的访问入口
         * @param recorder 关键操作记录器，需要记录关键操作的处理器自行使用
         * @return 命令执行结果响应
         */
        virtual ScmResponse Handle(const ScmRequest& request,
                                   const ServiceContext& ctx,
                                   KeyOperationRecorder& recorder) = 0;

        /**
         * @brief 恢复上次未完成的关键操作
         * @param record 关键操作记录，包含操作名与服务名等上下文
         * @param ctx 共享服务上下文，提供各领域子服务的访问入口
         * @return 恢复结果；默认实现返回警告，表示该操作不支持自动恢复
         * @details 当 scmd 启动时检测到上次操作被异常终止（result==2），
         *          CommandDispatcher::Recover 会根据操作名定位 handler 并调用此方法。
         *          支持恢复语义的处理器（如 install/upgrade）覆盖此方法实现具体恢复逻辑。
         */
        virtual ResultMsg Recover(const KeyOperationRecord& record, const ServiceContext& ctx) {
            (void)ctx;
            return MakeWarning("Operation does not support auto-recovery: " + record.optName);
        }
    };

}  // namespace qifeng::scm
