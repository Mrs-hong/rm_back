/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#pragma once
#include "common/types.h"
#include "service_manager/service_context.h"

#include <memory>

namespace qifeng::scm {
    class ConfigLoader;
    class ServiceManager;

    /**
     * @brief 服务主类：scmd的核心功能入口
     * @details 作为门面类协调 ConfigLoader、ServiceManager 及各领域服务组件，
     * 提供完整的服务生命周期管理。
     *
     *          业务方法已下沉至各领域服务（通过 ServiceContext 暴露），
     *          ServiceControl 仅保留初始化与上下文访问职责：
     *          - Init() 装配 ConfigLoader/ServiceManager 及各领域服务并填充 ServiceContext
     *          - GetConfigLoader()/GetServiceContext() 供 ScmServer 及外围服务访问依赖
     */
    class ServiceControl {
    public:
        /**
         * @brief 初始化服务主类
         * @details 加载配置、初始化日志系统、创建ServiceManager、启动已安装且autoStart的服务
         * @return ResultMsg 操作结果
         */
        ResultMsg Init();

        // === 扩展接口（供ScmServer/外围调用） ===

        /**
         * @brief 获取配置加载器
         * @return const ConfigLoader& 配置加载器引用
         */
        const ConfigLoader &GetConfigLoader() const;

        /**
         * @brief 获取共享依赖上下文（供 handler/ScmServer 直接访问子服务）
         * @details 基础依赖、serviceManager、databaseService、nginxManager、modelManager 与
         *          upgradeService 均在 Init() 中构造并就绪。
         * @return const ServiceContext& 共享依赖上下文引用
         */
        const ServiceContext &GetServiceContext() const;

    private:
        /**
         * @brief 启动时按 scmd.yaml.back 执行路径迁移
         * @details 读取 preinst 重命名生成的 scmd.yaml.back 获取旧 root_dir/model_dir，
         *          若与新配置不一致则迁移数据文件并重定向 systemd/nginx 软链接。
         *          迁移在 ServiceManager 构造前完成，保证后续目录初始化使用新路径。
         *          部分失败仅告警，不阻断启动。
         * @return ResultMsg 无需迁移或迁移成功返回成功；迁移部分失败记录到 msg 但仍返回成功
         */
        ResultMsg MigratePathsIfNeeded();

    private:
        bool mIsInit {false};                             // 是否初始化
        std::shared_ptr<ConfigLoader> mConfigLoader;      // 配置加载器
        std::shared_ptr<ServiceManager> mServiceManager;  // 服务管理器
        ServiceContext mContext;                          // 共享依赖上下文（含全部领域服务）
    };
}  // namespace qifeng::scm
