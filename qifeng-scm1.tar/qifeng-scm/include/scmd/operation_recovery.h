/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#pragma once

#include "scmd/command_dispatcher.h"
#include "service_manager/key_recoder.h"
#include "service_manager/service_context.h"

namespace qifeng::scm {

    /**
     * @brief 操作恢复服务
     * @details 从 ScmServer 抽出的操作恢复职责：读取上次未完成的关键操作记录，
     *          按 result 语义处理，result=2 时通过 CommandDispatcher::Recover 查表分发恢复。
     */
    class OperationRecoveryService {
    public:
        /**
         * @brief 构造函数
         * @param dispatcher 命令分发器，用于查表调用 handler 的 Recover 方法
         * @param ctx 共享服务上下文
         * @param recorder 关键操作记录器
         */
        OperationRecoveryService(CommandDispatcher& dispatcher,
                                 const ServiceContext& ctx,
                                 KeyOperationRecorder& recorder);

        /**
         * @brief 执行操作恢复
         * @details 读取上次操作记录，按 result 语义处理：
         *          0=成功→清除记录；1=失败→仅告警；2=进行中→通过 dispatcher.Recover 查表恢复
         */
        void Run();

    private:
        CommandDispatcher& mDispatcher;
        const ServiceContext& mContext;
        KeyOperationRecorder& mRecorder;
    };

}  // namespace qifeng::scm
