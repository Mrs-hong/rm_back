/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#pragma once

#include "common/types.h"

#include <string>

namespace qifeng::scm::utils {

    /// 旧路径信息（从 scmd.yaml.back 解析得到，用于启动时路径迁移）
    struct OldPathInfo {
        std::string rootDir;    // 旧 root_dir
        std::string modelDir;   // 旧 model_dir
    };

    /**
     * @brief 从备份配置文件解析旧路径
     * @details 使用 yaml-cpp 解析 scmd.yaml.back，仅提取 scmd.root_dir 与 scmd.model_dir。
     *          调用方据此判断是否需要执行路径迁移。
     * @param backupConfigPath scmd.yaml.back 完整路径
     * @param outInfo 输出旧路径信息
     * @return ResultMsg 文件不存在或解析失败返回错误，成功返回旧路径
     */
    ResultMsg ParseOldPathsFromBackup(const std::string &backupConfigPath, OldPathInfo &outInfo);

    // 路径等效比较：直接复用 utils::NormalizePath（path.h）做词法规范化后字符串比较，
    // 不访问文件系统，适合迁移前新路径尚未创建的场景。避免与 path.h 中基于 fs::canonical
    // 的 ResultMsg IsSamePath 重载冲突，故此处不再单独声明。

    /**
     * @brief 迁移 root_dir 下的子目录（services/data/backup/log/tmp）到新位置
     * @details 合并语义：新路径已有同名子目录则保留，旧子目录内容并入；
     *          跨文件系统时（EXDEV）自动回退到 copy+delete；
     *          迁移后清空旧子目录但保留旧 root_dir 本身（避免影响其他可能引用该路径的进程）。
     *          单个子目录迁移失败仅告警，不中断整体迁移。
     * @param oldRootDir 旧根目录绝对路径
     * @param newRootDir 新根目录绝对路径
     * @return ResultMsg 迁移结果，所有子目录均失败时返回错误
     */
    ResultMsg MigrateRootDirContents(const std::string &oldRootDir, const std::string &newRootDir);

    /**
     * @brief 迁移模型目录内容到新位置
     * @details 合并语义：新目录已有同名模型子目录则保留，旧内容并入；
     *          跨文件系统时（EXDEV）自动回退到 copy+delete。
     * @param oldModelDir 旧模型目录绝对路径
     * @param newModelDir 新模型目录绝对路径
     * @return ResultMsg 迁移结果
     */
    ResultMsg MigrateModelDir(const std::string &oldModelDir, const std::string &newModelDir);

    /**
     * @brief 重定向 systemd 单元软链接到新的 .init 目录
     * @details 扫描 /etc/systemd/system/ 下所有 scmd_*.service 软链接，
     *          若 target 以 oldInitDir 为前缀则删除重建指向 newInitDir 对应路径。
     *          仅处理 scm 管理的服务单元，单条失败仅告警不中断。
     * @param oldInitDir 旧 .init 目录绝对路径（<oldRootDir>/services/.init）
     * @param newInitDir 新 .init 目录绝对路径（<newRootDir>/services/.init）
     * @return ResultMsg 操作结果
     */
    ResultMsg RepointSystemdSymlinks(const std::string &oldInitDir, const std::string &newInitDir);

    /**
     * @brief 重定向 nginx 配置软链接到新的 serviceDir
     * @details 扫描 /etc/nginx/conf.d/scm_*.conf 与 /etc/nginx/snippets/scm_* 软链接，
     *          若 target 以 oldServiceDir 为前缀则删除重建指向 newServiceDir 对应路径。
     *          单条失败仅告警不中断。
     * @param oldServiceDir 旧 services 目录绝对路径（<oldRootDir>/services）
     * @param newServiceDir 新 services 目录绝对路径（<newRootDir>/services）
     * @return ResultMsg 操作结果
     */
    ResultMsg RepointNginxSymlinks(const std::string &oldServiceDir, const std::string &newServiceDir);

}  // namespace qifeng::scm::utils
