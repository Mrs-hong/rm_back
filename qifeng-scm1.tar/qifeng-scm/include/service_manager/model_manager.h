/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#pragma once
#include "common/types.h"
#include "service_manager/service_context.h"

#include <map>
#include <string>
#include <vector>

namespace qifeng::scm {

    /**
     * @brief 模型文件管理器
     * @details 从 ServiceManager 中提取的模型管理领域逻辑，负责模型的安装、停用、
     *          回退及备份清理等操作，并维护模型依赖服务的启停与状态恢复。
     *          持有 ServiceContext 引用以访问 ConfigLoader、FileManager 等共享依赖，
     *          通过 ServiceContext::serviceManager 调用服务启停能力。
     */
    class ModelManager {
    public:
        /**
         * @brief 构造函数
         * @param ctx 共享依赖上下文（需由调用方保活，领域服务成员需在构造前填充）
         */
        explicit ModelManager(const ServiceContext &ctx);

        /**
         * @brief 析构函数
         */
        ~ModelManager();

        ModelManager(const ModelManager &) = delete;
        ModelManager &operator=(const ModelManager &) = delete;
        ModelManager(ModelManager &&) = delete;
        ModelManager &operator=(ModelManager &&) = delete;

        // === 模型文件管理 ===

        /**
         * @brief 安装/升级模型文件（文件级合并）
         * @details 将 srcPath（目录或 tar 包）中的模型文件以文件粒度合并到 scmd.yaml 配置的
         *          model_dir 下：逐个文件复制，若目标已存在则重命名为 <file>.back 备份；
         *          自动停止依赖模型的服务，验证持续运行无影响后清除 .back 完成，否则按已替换
         *          文件列表精确回滚（删除新文件、恢复 .back）。可向已有模型目录增量添加或覆盖单个文件。
         * @param srcPath 模型源路径（目录或 tar/tar.gz 包）
         * @return ResultMsg 操作结果
         */
        ResultMsg AddModel(const std::string &srcPath);

        /**
         * @brief 停用并备份模型
         * @details 将 model_dir 下指定模型重命名为 <name>.back，验证依赖服务无影响后完成。
         * @param modelName 模型名（model_dir 下的文件或目录名）
         * @return ResultMsg 操作结果
         */
        ResultMsg ClearModel(const std::string &modelName);

        /**
         * @brief 安装模型并保留备份（用于一体化升级流程）
         * @details 与 AddModel 流程一致（文件级合并），但：
         *          1. 排除 excludeService（升级中的服务已停止，无需在此停止/启动）
         *          2. 成功后不清理 .back 备份，由调用方确认升级成功后调用 CleanModelBackupFiles 清理；
         *             升级失败则调用 RollbackModelFiles 恢复被覆盖文件
         * @param srcPath 模型源路径（目录或 tar/tar.gz 包）
         * @param excludeService 排除的服务名（不参与停止/启动/验证）
         * @param[out] modelName 输出安装的模型名（仅作标签，文件级合并不创建以 modelName 命名的子目录）
         * @param[out] backupFiles 输出本次产生的 .back 备份文件路径列表，供调用方清理/回退
         * @return ResultMsg 操作结果
         */
        ResultMsg AddModelWithBackupRetained(const std::string &srcPath, const std::string &excludeService,
                                             std::string &modelName, std::vector<std::string> &backupFiles);

        /**
         * @brief 清理模型备份文件（一体化升级成功后调用）
         * @details 逐个删除 AddModelWithBackupRetained 产生的 .back 备份文件。
         * @param backupFiles .back 备份文件路径列表
         * @return ResultMsg 操作结果（单个删除失败仅告警，不中断）
         */
        ResultMsg CleanModelBackupFiles(const std::vector<std::string> &backupFiles);

        /**
         * @brief 回退模型文件（一体化升级失败时调用）
         * @details 对 backupFiles 中每个 .back 文件：删除覆盖后产生的新文件，
         *          将 .back 恢复为原名。注意：仅回退被覆盖的文件，本次新增的文件（无 .back）不在此处理范围。
         * @param backupFiles .back 备份文件路径列表
         * @return ResultMsg 操作结果
         */
        ResultMsg RollbackModelFiles(const std::vector<std::string> &backupFiles);

    private:
        // === 模型管理辅助 ===

        /**
         * @brief 获取所有 need_model=true 的服务名
         * @return std::vector<std::string> 依赖模型的服务列表
         */
        std::vector<std::string> GetModelDependentServices();

        /**
         * @brief 获取所有 need_model=true 的服务名（排除指定服务）
         * @param excludeService 需排除的服务名（如正在升级的服务）
         * @return std::vector<std::string> 依赖模型的服务列表
         */
        std::vector<std::string> GetModelDependentServices(const std::string &excludeService);

        /**
         * @brief 停止指定服务列表，记录每个服务停止前的运行状态
         * @param serviceNames 服务名列表
         * @param preStates 输出参数，按服务名记录停止前是否在运行
         * @return ResultMsg 操作结果
         */
        ResultMsg StopServicesWithStateRecord(const std::vector<std::string> &serviceNames,
                                              std::map<std::string, bool> &preStates);

        /**
         * @brief 按停止前状态恢复服务（原本运行的启动，原本停止的保持停止）
         * @param preStates 服务名 -> 停止前是否运行
         * @return ResultMsg 操作结果
         */
        ResultMsg RestoreServicesByState(const std::map<std::string, bool> &preStates);

        /**
         * @brief 启动指定服务列表并按各自 keep_alive_time_sec 验证持续运行
         * @details 每个服务启动后等待其 keepAliveTimeSec 秒再检查活跃状态；
         *          keepAliveTimeSec 为 0 则跳过该服务的验证。
         * @param serviceNames 服务名列表
         * @return ResultMsg 全部启动并验证通过返回成功，否则返回失败原因
         */
        ResultMsg StartServicesAndWaitRunning(const std::vector<std::string> &serviceNames);

        /**
         * @brief 校验模型名合法（非空、不以 .back 结尾）
         * @param modelName 模型名
         * @return ResultMsg 合法返回成功
         */
        ResultMsg ValidateModelName(const std::string &modelName) const;

    private:
        const ServiceContext &mCtx;
    };

}  // namespace qifeng::scm
