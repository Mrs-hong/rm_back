/*
 * Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
 */

#include "scmd/command_dispatcher.h"

#include "common/types.h"
#include "ipc/data_def.h"
#include "scmd/command_handler.h"
#include "service_manager/key_recoder.h"
#include "service_manager/service_context.h"

#include <gtest/gtest.h>

namespace qifeng::scm {

    // 用于测试的简单 Mock 处理器
    class MockHandler : public ICommandHandler {
    public:
        explicit MockHandler(ScmCommand cmd) : mCommand(cmd) {
        }

        ScmCommand GetCommand() const override {
            return mCommand;
        }

        ScmResponse Handle(const ScmRequest& /*request*/,
                           const ServiceContext& /*ctx*/,
                           KeyOperationRecorder& /*recorder*/) override {
            ScmResponse resp;
            resp.code = 0;
            resp.message = "handled";
            return resp;
        }

    private:
        ScmCommand mCommand;
    };

    TEST(CommandDispatcherTest, RegisterAndDispatch) {
        CommandDispatcher dispatcher;
        dispatcher.Register(std::make_unique<MockHandler>(ScmCommand::LIST));
        dispatcher.Register(std::make_unique<MockHandler>(ScmCommand::VERSION));

        ScmRequest listReq{ListRequest{}};
        ScmRequest versionReq{VersionRequest{}};

        // MockHandler 不访问 ctx 字段，使用默认构造的 ServiceContext（各 shared_ptr 为 nullptr）即可
        ServiceContext ctx;
        KeyOperationRecorder recorder;

        ScmResponse listResp = dispatcher.Dispatch(listReq, ctx, recorder);
        EXPECT_EQ(listResp.code, 0);
        EXPECT_EQ(listResp.message, "handled");

        ScmResponse versionResp = dispatcher.Dispatch(versionReq, ctx, recorder);
        EXPECT_EQ(versionResp.code, 0);
        EXPECT_EQ(versionResp.message, "handled");
    }

    TEST(CommandDispatcherTest, UnknownCommand) {
        CommandDispatcher dispatcher;
        dispatcher.Register(std::make_unique<MockHandler>(ScmCommand::LIST));

        ScmRequest unknownReq{KillRequest{}};
        ServiceContext ctx;
        KeyOperationRecorder recorder;

        ScmResponse resp = dispatcher.Dispatch(unknownReq, ctx, recorder);
        EXPECT_EQ(resp.code, -1);
        EXPECT_EQ(resp.message, "Unknown command");
    }

    TEST(CommandDispatcherTest, DuplicateRegistrationIgnored) {
        CommandDispatcher dispatcher;
        dispatcher.Register(std::make_unique<MockHandler>(ScmCommand::LIST));
        dispatcher.Register(std::make_unique<MockHandler>(ScmCommand::LIST));

        ScmRequest req{ListRequest{}};
        ServiceContext ctx;
        KeyOperationRecorder recorder;

        ScmResponse resp = dispatcher.Dispatch(req, ctx, recorder);
        EXPECT_EQ(resp.code, 0);
        EXPECT_EQ(resp.message, "handled");
    }

}  // namespace qifeng::scm
