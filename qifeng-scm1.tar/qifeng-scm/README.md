# qifeng_scm 服务管理系统

## 1. 项目简介

qifeng_scm（Qifeng Service Control Manager）是面向 Linux 平台的服务管理系统，通过 systemd 统一管理第三方服务的生命周期，支持服务安装、启动、停止、监控、卸载、更新及数据库自动初始化。系统由两个主程序组成：

| 程序         | 运行身份 | 职责                                                |
| ------------ | -------- | --------------------------------------------------- |
| `qf_scmd`    | root     | 守护进程，通过 systemd 管理服务生命周期，监听 UDS socket 接收控制指令 |
| `qf_scmc`    | 任意用户 | CLI 客户端，通过 UDS 与 `qf_scmd` 通信，执行服务管理命令           |

## 2. 代码目录结构

```
qifeng_scm/
├── src/                       # 源码目录
│   ├── scmd/                  # 守护进程（qf_scmd）主入口与 UDS 服务端
│   ├── scmctl/                # CLI 客户端（qf_scmc）命令解析与分发
│   ├── service_manager/       # 服务安装/卸载/启停/状态查询核心逻辑
│   ├── ipc/                   # UDS 通信与 DBus（systemd）接口
│   ├── common/                # 公共配置加载、工具函数与类型定义
│   ├── service_tool/          # 服务工具（如 MariaDB 交互工具）
│   └── checker/               # 硬件/自检模块（磁盘、网络、TPU、模型推理等检查器）
├── include/                   # 头文件目录（与 src/ 结构对应）
├── config/                    # 参考配置文件（scmd.yaml、selftest.json，安装时复制到 /etc/qifeng_scm/）
├── debian/                    # deb 打包相关文件（systemd 单元、维护脚本等）
├── third_part/                # 第三方依赖（qifeng_framework）
├── CMakeLists.txt             # 顶层 CMake 配置
├── build.sh                   # 编译脚本
└── README.md                  # 本文档
```

## 3. 编译说明

### 3.1 环境要求

- 操作系统：Linux（Debian / Ubuntu 系列）
- 编译器：GCC >= 9 或 Clang >= 10
- CMake：>= 3.15
- 依赖库：`libsystemd-dev`（提供 `sd-bus.h`）、`qifeng_framework`（yaml-cpp、spdlog、cppjson 等，缺失时 `build.sh` 会自动下载）

安装系统依赖（Debian / Ubuntu）：

```bash
sudo apt update
sudo apt install -y libsystemd-dev
```

### 3.2 使用 build.sh 编译（推荐）

```bash
# Release 编译主项目（默认）
./build.sh

# Debug 编译
./build.sh -d

# 编译所有目标（含测试）
./build.sh all -r

# 仅编译测试目标
./build.sh test -r

# 编译并安装到指定目录
./build.sh -r -i /opt/qifeng

# 清除 build 目录
./build.sh clean
```

### 3.3 直接使用 CMake 编译

```bash
# 配置（Release）
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release

# 编译
cmake --build build -j$(nproc)

# 如需编译测试，添加 -DBUILD_TESTING=ON
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
```

### 3.4 编译产物

- `build/bin/qf_scmd` — 守护进程可执行文件
- `build/bin/qf_scmc` — CLI 客户端可执行文件

## 4. 打包说明

```bash
# 1. Release 编译
./build.sh -r

# 2. 进入 build 目录并打包
cd build
cpack -G DEB
```

- **包名**：`qifeng_scm-0.0.1-Linux.deb`
- **位置**：`build/qifeng_scm-0.0.1-Linux.deb`

包内主要内容：

| 路径                                       | 说明             |
| ------------------------------------------ | ---------------- |
| `/usr/bin/qf_scmd`                         | 守护进程可执行文件 |
| `/usr/bin/qf_scmc`                         | CLI 客户端可执行文件 |
| `/usr/lib/qifeng_scm/*.so*`                | 第三方依赖动态库   |
| `/lib/systemd/system/qifeng_scmd.service`  | systemd 服务单元  |
| `/etc/qifeng_scm/scmd.yaml`                | 参考配置文件       |
| `/etc/ld.so.conf.d/qifeng_scm.conf`        | 私有库搜索路径配置 |
| `postinst` / `prerm` / `postrm`            | deb 维护脚本      |

## 5. 命令使用说明

```bash
# 列出已安装服务
qf_scmc list

# 安装服务（以 mariadb 为例）
qf_scmc install -n mariadb --tar_dir ./t_mariadb.tar.gz

# 启动服务
qf_scmc start -n mariadb

# 查看服务状态
qf_scmc info -n mariadb

# 停止服务
qf_scmc stop -n mariadb

# 卸载服务
qf_scmc uninstall -n mariadb

# 查看服务 journal 日志（默认 10 行）
qf_scmc slog -n mariadb --count 20

# 独立配置 nginx（使静态文件和反向代理配置生效，-d 为目录或 tar.gz）
qf_scmc init_nginx -d ./nginx_conf

# 安装/升级模型文件（停止依赖服务→替换模型→验证→恢复服务状态）
qf_scmc add_model -d ./model_dir
```

> 注：`qf_scmc start` / `qf_scmc stop` 不带 `-n` 时操作 `qifeng_scmd` 守护进程自身，需 root 权限。

---

Copyright (C) 2026-2026 Qifeng Shunshi Co., Ltd. All rights reserved.
